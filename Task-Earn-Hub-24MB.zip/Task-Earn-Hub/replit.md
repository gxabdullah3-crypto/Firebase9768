# Earn Space

A task-based micro-earning platform for Bangladeshi users. Users complete tasks posted by admin, submit screenshots as proof, and earn money (BDT) to withdraw via bKash or Nagad.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/earn-space run dev` — run the frontend (port 24831)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string, `SESSION_SECRET` — session secret

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5 + express-session + connect-pg-simple (session stored in PostgreSQL)
- Auth: Custom bcrypt + session (first registered user becomes admin)
- DB: PostgreSQL + Drizzle ORM
- Frontend: React + Vite + TanStack Query + shadcn/ui
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- File upload: multer (screenshots up to 10MB, stored in /uploads folder)

## Where things live

- `lib/api-spec/openapi.yaml` — API contract (source of truth)
- `lib/db/src/schema/` — Drizzle table definitions (users, tasks, submissions, withdrawals, settings, sessions)
- `artifacts/api-server/src/routes/` — Express route handlers
- `artifacts/api-server/src/middlewares/requireAuth.ts` — auth + admin middleware
- `artifacts/earn-space/src/` — React frontend (pages/, components/, hooks/)

## Architecture decisions

- First registered user automatically gets `admin` role; subsequent users get `user` role.
- Sessions are stored in PostgreSQL (connect-pg-simple) using the `session` table.
- Screenshot uploads are stored locally under `/uploads/` folder in the API server's working directory and served at `/api/uploads/:filename`.
- Referral commission is applied automatically when a task submission is approved: % of reward goes to the referrer.
- Withdrawal requests deduct balance immediately on request; rejected withdrawals refund the balance.

## Product

- **Users**: Register/login, browse active tasks, submit work (screenshot + description), track submissions, request withdrawals (bKash/Nagad, min 50 BDT), view referrals and referral earnings.
- **Admin** (first account): Post/edit/delete tasks, review and approve/reject submissions, approve/reject withdrawals, manage users, set referral commission % and min withdrawal amount.

## User preferences

- App name: Earn Space
- Withdrawal minimum: 50 BDT
- Methods: bKash and Nagad
- Screenshot upload: gallery only, image/* type, max 10MB
- No bugs policy: auth redirects, form submissions, and all CRUD operations must work correctly.

## Gotchas

- After any OpenAPI spec change, run codegen before using updated types.
- The `session` table is created automatically by `connect-pg-simple` (createTableIfMissing: true).
- File uploads are served at `/api/uploads/:filename` (not `/uploads/`).
- Balance is stored as numeric string in DB; always convert with `Number()` before arithmetic.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
