import { useState } from "react";
import {
  useListNotifications,
  useMarkAllNotificationsRead,
  useMarkNotificationRead,
  getListNotificationsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export function NotificationBell() {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const { data: notifications } = useListNotifications({
    query: {
      refetchInterval: 30_000,
      queryKey: getListNotificationsQueryKey(),
    },
  });

  const markAllRead = useMarkAllNotificationsRead();
  const markOneRead = useMarkNotificationRead();

  const unread = notifications?.filter((n) => !n.read).length ?? 0;

  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: getListNotificationsQueryKey() });

  const handleMarkAll = () => {
    markAllRead.mutate(undefined, {
      onSuccess: () => invalidate(),
    });
  };

  const handleMarkOne = (id: number) => {
    markOneRead.mutate({ id }, { onSuccess: () => invalidate() });
  };

  const typeColor = (t: string) => {
    if (t === "success") return "border-l-green-500 bg-green-50/50";
    if (t === "error") return "border-l-red-500 bg-red-50/50";
    return "border-l-blue-500 bg-blue-50/50";
  };

  const typeIcon = (t: string) => {
    if (t === "success") return "✅";
    if (t === "error") return "❌";
    return "ℹ️";
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="relative h-9 w-9"
          data-testid="button-notifications"
        >
          <Bell className="h-5 w-5" />
          {unread > 0 && (
            <span className="absolute -top-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent
        className="w-80 p-0 shadow-xl"
        align="end"
        sideOffset={8}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b">
          <h3 className="font-semibold text-sm">
            নোটিফিকেশন
            {unread > 0 && (
              <Badge variant="secondary" className="ml-2 text-xs">
                {unread} নতুন
              </Badge>
            )}
          </h3>
          {unread > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 text-xs text-muted-foreground hover:text-foreground"
              onClick={handleMarkAll}
              disabled={markAllRead.isPending}
            >
              সব পড়া হয়েছে
            </Button>
          )}
        </div>

        <div className="max-h-80 overflow-y-auto">
          {!notifications || notifications.length === 0 ? (
            <div className="py-8 text-center">
              <Bell className="h-8 w-8 text-muted-foreground/30 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">কোনো নোটিফিকেশন নেই</p>
            </div>
          ) : (
            <div className="divide-y">
              {notifications.map((n) => (
                <div
                  key={n.id}
                  data-testid={`notification-${n.id}`}
                  className={cn(
                    "px-4 py-3 border-l-4 transition-colors cursor-pointer",
                    typeColor(n.type),
                    !n.read && "font-medium",
                    n.read && "opacity-60"
                  )}
                  onClick={() => !n.read && handleMarkOne(n.id)}
                >
                  <div className="flex items-start gap-2">
                    <span className="text-base flex-shrink-0 mt-0.5">{typeIcon(n.type)}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs leading-relaxed">{n.message}</p>
                      <p className="text-[10px] text-muted-foreground mt-1">
                        {new Date(n.createdAt).toLocaleString("bn-BD")}
                      </p>
                    </div>
                    {!n.read && (
                      <div className="h-2 w-2 rounded-full bg-primary flex-shrink-0 mt-1" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
