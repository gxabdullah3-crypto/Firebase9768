import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import NotFound from "@/pages/not-found";

import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import Tasks from "@/pages/tasks";
import TaskDetail from "@/pages/task-detail";
import Submissions from "@/pages/submissions";
import Withdraw from "@/pages/withdraw";
import Referral from "@/pages/referral";
import DownloadApp from "@/pages/download";
import Support from "@/pages/support";

import AdminDashboard from "@/pages/admin/dashboard";
import AdminTasks from "@/pages/admin/tasks";
import AdminSubmissions from "@/pages/admin/submissions";
import AdminWithdrawals from "@/pages/admin/withdrawals";
import AdminUsers from "@/pages/admin/users";
import AdminSettings from "@/pages/admin/settings";
import AdminAssistants from "@/pages/admin/assistants";
import Investments from "@/pages/investments";
import AdminInvestments from "@/pages/admin/investments";

const queryClient = new QueryClient();

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        
        {/* User Routes */}
        <Route path="/" component={Dashboard} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/tasks" component={Tasks} />
        <Route path="/tasks/:id" component={TaskDetail} />
        <Route path="/submissions" component={Submissions} />
        <Route path="/withdraw" component={Withdraw} />
        <Route path="/investments" component={Investments} />
        <Route path="/referral" component={Referral} />
        <Route path="/download" component={DownloadApp} />
        <Route path="/support" component={Support} />

        {/* Admin Routes */}
        <Route path="/admin" component={AdminDashboard} />
        <Route path="/admin/tasks" component={AdminTasks} />
        <Route path="/admin/submissions" component={AdminSubmissions} />
        <Route path="/admin/withdrawals" component={AdminWithdrawals} />
        <Route path="/admin/users" component={AdminUsers} />
        <Route path="/admin/investments" component={AdminInvestments} />
        <Route path="/admin/settings" component={AdminSettings} />
        <Route path="/admin/assistants" component={AdminAssistants} />

        {/* Assistant Routes — shared task screens, server limits data to owned tasks */}
         <Route path="/assistant" component={AdminTasks} />
        <Route path="/assistant/tasks" component={AdminTasks} />
        <Route path="/assistant/submissions" component={AdminSubmissions} />

        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
