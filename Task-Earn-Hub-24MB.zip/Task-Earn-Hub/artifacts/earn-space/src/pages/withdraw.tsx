import { useState } from "react";
import {
  useGetMe,
  useRequestWithdrawal,
  useListWithdrawals,
  useGetSettings,
  useListReferrals,
  getGetMeQueryKey,
  getListWithdrawalsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Wallet, AlertCircle, Lock, Users, CheckCircle2, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function Withdraw() {
  const queryClient = useQueryClient();
  const { data: user } = useGetMe();
  const { data: withdrawals } = useListWithdrawals();
  const { data: settings } = useGetSettings();
  const { data: team } = useListReferrals();
  const requestWithdrawal = useRequestWithdrawal();
  const { toast } = useToast();

  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("bkash");
  const [accountNumber, setAccountNumber] = useState("");

  const balance = user?.balance ?? 0;
  const minWithdrawal = settings?.minWithdrawal ?? 50;
  // Only Active accounts count toward the five-referral withdrawal requirement.
  const directReferrals = team?.direct?.filter((member) => member.status === "active").length ?? 0;
  const REQUIRED_REFERRALS = 5;
  const withdrawalUnlocked = directReferrals >= REQUIRED_REFERRALS;
  const progress = Math.min((directReferrals / REQUIRED_REFERRALS) * 100, 100);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);

    if (numAmount > balance) {
      toast({ title: "অপর্যাপ্ত ব্যালেন্স", description: "আপনার ব্যালেন্সের চেয়ে বেশি উইথড্রয়াল করা যাবে না।", variant: "destructive" });
      return;
    }

    requestWithdrawal.mutate(
      { data: { amount: numAmount, method, accountNumber } },
      {
        onSuccess: () => {
          toast({ title: "রিকোয়েস্ট জমা হয়েছে!", description: "অ্যাডমিন অনুমোদনের পর আপনার অ্যাকাউন্টে টাকা পাঠানো হবে।" });
          setAmount("");
          setAccountNumber("");
          queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListWithdrawalsQueryKey() });
        },
        onError: (err: unknown) => {
          const msg = (err as { response?: { data?: { error?: string } } })?.response?.data?.error || "রিকোয়েস্ট জমা হয়নি।";
          toast({ title: "ব্যর্থ হয়েছে", description: msg, variant: "destructive" });
        },
      }
    );
  };

  const statusLabel = (s: string) =>
    s === "approved" ? "অনুমোদিত" : s === "rejected" ? "প্রত্যাখ্যাত" : "অপেক্ষমান";

  const methodLabel = (m: string) => (m === "bkash" ? "bKash" : "Nagad");

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">উইথড্রয়াল</h1>
        <p className="text-muted-foreground mt-1 text-sm">আপনার আয় মোবাইল ব্যাংকিংয়ে পাঠান।</p>
      </div>

      {/* Referral Lock Banner */}
      {!withdrawalUnlocked && (
        <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid rgba(245,158,11,0.30)', background: 'rgba(245,158,11,0.06)' }}>
          {/* Gold top bar */}
          <div className="h-1" style={{ background: 'linear-gradient(90deg,#F59E0B,#FACC15,#D97706)' }} />
          <div className="p-5">
            <div className="flex items-start gap-4">
              <div className="h-12 w-12 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: 'rgba(245,158,11,0.15)' }}>
                <Lock className="h-6 w-6" style={{ color: '#F59E0B' }} />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-base" style={{ color: '#F59E0B' }}>উইথড্রয়াল লক আছে</h3>
                <p className="text-sm text-muted-foreground mt-0.5">
                  উইথড্রয়াল unlock করতে কমপক্ষে <span className="font-bold" style={{ color: '#F59E0B' }}>৫ জন</span> বন্ধুকে রেফার করুন।
                </p>

                {/* Progress */}
                <div className="mt-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-muted-foreground flex items-center gap-1.5">
                      <Users className="h-3.5 w-3.5" />
                      রেফারেল অগ্রগতি
                    </span>
                    <span className="text-sm font-bold" style={{ color: '#F59E0B' }}>
                      {directReferrals}/{REQUIRED_REFERRALS}
                    </span>
                  </div>
                  {/* Progress bar */}
                  <div className="h-2.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.08)' }}>
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${progress}%`,
                        background: 'linear-gradient(90deg,#F59E0B,#FACC15)',
                        boxShadow: '0 0 8px rgba(245,158,11,0.5)',
                      }}
                    />
                  </div>
                  {/* Steps */}
                  <div className="mt-3 flex gap-2 flex-wrap">
                    {Array.from({ length: REQUIRED_REFERRALS }).map((_, i) => (
                      <div key={i} className="flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium"
                        style={i < directReferrals
                          ? { background: 'rgba(52,211,153,0.15)', color: '#34D399', border: '1px solid rgba(52,211,153,0.25)' }
                          : { background: 'rgba(255,255,255,0.05)', color: 'rgba(255,255,255,0.35)', border: '1px solid rgba(255,255,255,0.08)' }
                        }>
                        {i < directReferrals
                          ? <CheckCircle2 className="h-3 w-3" />
                          : <span className="h-3 w-3 rounded-full inline-flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.15)', fontSize: '9px' }}>{i+1}</span>
                        }
                        জন {i + 1}
                      </div>
                    ))}
                  </div>
                </div>

                <Link href="/referral">
                  <button className="mt-4 w-full flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold transition-all hover:opacity-90"
                    style={{ background: 'linear-gradient(90deg,#F59E0B,#D97706)', color: '#060D1F' }}>
                    <Users className="h-4 w-4" />
                    রেফার করুন এবং উইথড্রয়াল unlock করুন
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Unlocked success banner */}
      {withdrawalUnlocked && (
        <div className="flex items-center gap-3 rounded-xl p-4"
          style={{ background: 'rgba(52,211,153,0.08)', border: '1px solid rgba(52,211,153,0.25)' }}>
          <CheckCircle2 className="h-5 w-5 flex-shrink-0" style={{ color: '#34D399' }} />
          <p className="text-sm font-medium" style={{ color: '#34D399' }}>
            উইথড্রয়াল unlock! আপনি {directReferrals} জন রেফার করেছেন।
          </p>
        </div>
      )}

      <div className="grid gap-6 md:grid-cols-2">
        {/* Request Form */}
        <div className="rounded-2xl overflow-hidden" style={{ background: 'hsl(var(--card))', border: '1px solid rgba(245,158,11,0.15)' }}>
          <div className="p-5" style={{ borderBottom: '1px solid rgba(245,158,11,0.10)' }}>
            <h2 className="font-bold text-base flex items-center gap-2">
              <Wallet className="h-5 w-5" style={{ color: '#F59E0B' }} />
              উইথড্রয়াল রিকোয়েস্ট
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              বর্তমান ব্যালেন্স:{" "}
              <span className="font-bold" style={{ color: '#F59E0B' }}>৳{balance.toFixed(2)}</span>
            </p>
          </div>

          <form onSubmit={handleSubmit} className="p-5 space-y-4">
            {!withdrawalUnlocked && (
              <div className="flex items-start gap-2 rounded-xl p-3 text-sm"
                style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.20)', color: '#FCD34D' }}>
                <Lock className="h-4 w-4 flex-shrink-0 mt-0.5" />
                <p>প্রথমে ৫ জন রেফার করুন, তারপর উইথড্রয়াল করতে পারবেন।</p>
              </div>
            )}

            {withdrawalUnlocked && balance < minWithdrawal && (
              <div className="flex items-start gap-2 rounded-xl p-3 text-sm"
                style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.20)', color: '#FCD34D' }}>
                <AlertCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                <p>সর্বনিম্ন উইথড্রয়াল ৳{minWithdrawal} BDT। আরও আয় করুন।</p>
              </div>
            )}

            <div className="space-y-2">
              <Label>পরিমাণ (BDT)</Label>
              <Input
                data-testid="input-withdrawal-amount"
                type="number"
                min={minWithdrawal}
                max={balance}
                step="0.01"
                placeholder={`সর্বনিম্ন ৳${minWithdrawal}`}
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                disabled={!withdrawalUnlocked}
                required
              />
            </div>

            <div className="space-y-2">
              <Label>পেমেন্ট মেথড</Label>
              <Select value={method} onValueChange={setMethod} disabled={!withdrawalUnlocked}>
                <SelectTrigger data-testid="select-withdrawal-method">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bkash">bKash</SelectItem>
                  <SelectItem value="nagad">Nagad</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>অ্যাকাউন্ট নম্বর</Label>
              <Input
                data-testid="input-withdrawal-account"
                type="tel"
                placeholder="01XXXXXXXXX"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                disabled={!withdrawalUnlocked}
                required
              />
            </div>

            <Button
              data-testid="button-submit-withdrawal"
              type="submit"
              className="w-full"
              disabled={!withdrawalUnlocked || requestWithdrawal.isPending || balance < minWithdrawal}
            >
              {!withdrawalUnlocked
                ? <><Lock className="h-4 w-4 mr-2" /> লক আছে</>
                : requestWithdrawal.isPending
                ? "জমা হচ্ছে..."
                : "উইথড্রয়াল রিকোয়েস্ট করুন"
              }
            </Button>
          </form>
        </div>

        {/* History */}
        <div className="rounded-2xl overflow-hidden" style={{ background: 'hsl(var(--card))', border: '1px solid rgba(245,158,11,0.15)' }}>
          <div className="p-5" style={{ borderBottom: '1px solid rgba(245,158,11,0.10)' }}>
            <h2 className="font-bold text-base">উইথড্রয়াল ইতিহাস</h2>
          </div>
          <div className="p-5">
            {!withdrawals || withdrawals.length === 0 ? (
              <div className="py-8 text-center">
                <Wallet className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">কোনো উইথড্রয়াল ইতিহাস নেই।</p>
              </div>
            ) : (
              <div className="space-y-3">
                {withdrawals.map((w) => (
                  <div key={w.id} data-testid={`withdrawal-row-${w.id}`}
                    className="flex justify-between items-start pb-3 last:pb-0"
                    style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                    <div>
                      <p className="font-semibold text-sm">
                        ৳{w.amount}{" "}
                        <span className="text-muted-foreground font-normal">via {methodLabel(w.method)}</span>
                      </p>
                      <p className="text-xs text-muted-foreground font-mono">{w.accountNumber}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(w.createdAt).toLocaleDateString("bn-BD")}
                      </p>
                      {w.rejectionReason && (
                        <p className="text-xs text-destructive mt-0.5">{w.rejectionReason}</p>
                      )}
                    </div>
                    <span className="text-xs font-semibold px-2.5 py-1 rounded-full flex-shrink-0"
                      style={w.status === "approved"
                        ? { background: 'rgba(52,211,153,0.15)', color: '#34D399', border: '1px solid rgba(52,211,153,0.25)' }
                        : w.status === "rejected"
                        ? { background: 'rgba(239,68,68,0.15)', color: '#F87171', border: '1px solid rgba(239,68,68,0.25)' }
                        : { background: 'rgba(245,158,11,0.15)', color: '#FCD34D', border: '1px solid rgba(245,158,11,0.25)' }
                      }>
                      {statusLabel(w.status)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
