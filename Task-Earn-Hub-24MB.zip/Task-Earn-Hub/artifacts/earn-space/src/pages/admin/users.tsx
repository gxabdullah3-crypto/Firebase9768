import { useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowDownLeft, ArrowUpRight, CircleDollarSign, Search, ShieldCheck, Users } from "lucide-react";
import {
  getListBalanceTransactionsQueryKey,
  getListUsersQueryKey,
  useAdjustUserBalance,
  useListUsers,
} from "@workspace/api-client-react";
import type { BalanceAdjustmentInput, UserProfile } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

const adjustmentSchema = z.object({
  amount: z.coerce.number().positive("Amount must be greater than zero"),
  direction: z.enum(["credit", "debit"]),
  reason: z.string().trim().min(3, "Please provide a reason").max(300),
});
type AdjustmentValues = z.infer<typeof adjustmentSchema>;
const money = (amount: number) => `৳${Number(amount ?? 0).toLocaleString("en-BD", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

function UserAdjustmentForm({ user, onClose }: { user: UserProfile; onClose: () => void }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const adjustment = useAdjustUserBalance();
  const lastRequest = useRef<{ fingerprint: string; key: string } | null>(null);
  const form = useForm<AdjustmentValues>({
    resolver: zodResolver(adjustmentSchema),
    defaultValues: { amount: 0, direction: "credit", reason: "" },
  });

  const onSubmit = (values: AdjustmentValues) => {
    const fingerprint = `${values.amount}|${values.direction}|${values.reason.trim()}`;
    const key = lastRequest.current?.fingerprint === fingerprint
      ? lastRequest.current.key
      : `admin-${user.id}-${crypto.randomUUID()}`;
    lastRequest.current = { fingerprint, key };
    const data: BalanceAdjustmentInput = {
      amount: Number(values.amount),
      direction: values.direction,
      reason: values.reason.trim(),
      idempotencyKey: key,
    };
    adjustment.mutate({ userId: user.id, data }, {
      onSuccess: async (transaction) => {
        lastRequest.current = null;
        toast({
          title: values.direction === "credit" ? "Balance credited" : "Balance debited",
          description: `${money(Math.abs(transaction.amount))} applied to ${user.name}'s main wallet.`,
        });
        await Promise.all([
          queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getListBalanceTransactionsQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getListBalanceTransactionsQueryKey({ userId: user.id }) }),
        ]);
        onClose();
      },
      onError: () => toast({ title: "Adjustment was not applied", description: "Confirm the amount and available balance, then try again.", variant: "destructive" }),
    });
  };

  return (
    <div className="mt-4 rounded-xl border border-amber-300/15 bg-[#081327] p-4" data-testid={`form-user-adjustment-${user.id}`}>
      <div className="mb-4 flex items-center gap-2"><CircleDollarSign className="h-4 w-4 text-amber-300" /><div><p className="text-sm font-semibold text-amber-50">Main wallet adjustment</p><p className="text-xs text-slate-500">This action is recorded in the transaction ledger.</p></div></div>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-3 sm:grid-cols-2">
          <FormField control={form.control} name="direction" render={({ field }) => <FormItem><FormLabel className="text-xs text-slate-300">Adjustment type</FormLabel><Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger data-testid={`select-adjustment-direction-${user.id}`}><SelectValue placeholder="Choose direction" /></SelectTrigger></FormControl><SelectContent><SelectItem value="credit"><span className="flex items-center gap-2"><ArrowDownLeft className="h-3.5 w-3.5 text-emerald-300" />Credit main wallet</span></SelectItem><SelectItem value="debit"><span className="flex items-center gap-2"><ArrowUpRight className="h-3.5 w-3.5 text-rose-300" />Debit main wallet</span></SelectItem></SelectContent></Select><FormMessage /></FormItem>} />
          <FormField control={form.control} name="amount" render={({ field }) => <FormItem><FormLabel className="text-xs text-slate-300">Amount (৳)</FormLabel><FormControl><Input {...field} type="number" min="0.01" step="0.01" placeholder="0.00" data-testid={`input-adjustment-amount-${user.id}`} /></FormControl><FormMessage /></FormItem>} />
          <FormField control={form.control} name="reason" render={({ field }) => <FormItem className="sm:col-span-2"><FormLabel className="text-xs text-slate-300">Reason</FormLabel><FormControl><Input {...field} placeholder="e.g. correction after support review" data-testid={`input-adjustment-reason-${user.id}`} /></FormControl><FormMessage /></FormItem>} />
          {adjustment.error && <p className="text-xs text-rose-300 sm:col-span-2" role="alert">Could not update this user's balance. Check the available balance for debits.</p>}
          <div className="flex justify-end gap-2 sm:col-span-2"><Button type="button" variant="outline" size="sm" onClick={onClose} disabled={adjustment.isPending} data-testid={`button-cancel-adjustment-${user.id}`}>Cancel</Button><Button type="submit" size="sm" className="bg-amber-400 font-semibold text-[#111b2a] hover:bg-amber-300" disabled={adjustment.isPending} data-testid={`button-submit-adjustment-${user.id}`}>{adjustment.isPending ? "Applying…" : "Apply adjustment"}</Button></div>
        </form>
      </Form>
    </div>
  );
}

export default function AdminUsers() {
  const usersQuery = useListUsers({ query: { queryKey: getListUsersQueryKey() } });
  const [search, setSearch] = useState("");
  const [adjustingUserId, setAdjustingUserId] = useState<number | null>(null);
  const filtered = usersQuery.data?.filter((user) =>
    user.name.toLowerCase().includes(search.toLowerCase()) ||
    user.email.toLowerCase().includes(search.toLowerCase())
  ) ?? [];

  return (
    <div className="mx-auto max-w-6xl space-y-6 pb-10" data-testid="page-admin-users">
      <header className="flex flex-col justify-between gap-4 border-b border-amber-300/10 pb-6 sm:flex-row sm:items-end">
        <div><div className="mb-2 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[.24em] text-amber-300/70"><ShieldCheck className="h-3.5 w-3.5" /> Administration · Accounts</div><h1 className="text-3xl font-bold tracking-tight text-amber-50">User directory</h1><p className="mt-2 text-sm text-slate-400">Review member balances and make documented main-wallet corrections.</p></div>
        <div className="rounded-xl border border-amber-200/10 bg-[#0b1830] px-4 py-3"><p className="text-[10px] uppercase tracking-widest text-slate-500">Members</p><p className="mt-1 font-mono text-xl font-semibold text-amber-300" data-testid="text-user-count">{usersQuery.data?.length ?? 0}</p></div>
      </header>

      <div className="relative max-w-xl">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
        <Input data-testid="input-user-search" placeholder="Search name or email…" value={search} onChange={(event) => setSearch(event.target.value)} className="border-amber-200/10 bg-[#0b1830] pl-9 placeholder:text-slate-600" />
      </div>

      <Card className="overflow-hidden border-amber-200/10 bg-[#0b1830]">
        <CardHeader className="border-b border-amber-100/[.08] bg-amber-300/[.025]"><CardTitle className="flex items-center gap-2 text-base text-amber-50"><Users className="h-4 w-4 text-amber-300" />Member accounts <span className="ml-auto text-xs font-normal text-slate-500">{usersQuery.data?.length ?? 0} total</span></CardTitle></CardHeader>
        <CardContent className="p-0">
          {usersQuery.isLoading ? <div className="space-y-3 p-5">{[0, 1, 2].map((item) => <Skeleton key={item} className="h-24 rounded-xl bg-primary/5" />)}</div> : usersQuery.error ? (
            <div className="py-12 text-center"><p className="font-medium text-rose-200">Member directory could not be loaded</p><p className="mt-1 text-sm text-slate-400">Retry to check the current account balances.</p><Button variant="outline" className="mt-4" onClick={() => void usersQuery.refetch()} data-testid="button-retry-users">Retry</Button></div>
          ) : filtered.length === 0 ? (
            <div className="px-6 py-14 text-center"><Users className="mx-auto h-7 w-7 text-slate-500" /><p className="mt-3 font-medium text-slate-200">{search ? "No members match your search" : "No members yet"}</p><p className="mt-1 text-sm text-slate-500">{search ? "Try a different name or email address." : "New member accounts will appear here."}</p></div>
          ) : (
            <div className="divide-y divide-amber-100/[.07]">
              {filtered.map((user) => (
                <div key={user.id} data-testid={`user-row-${user.id}`} className="p-4 sm:p-5">
                  <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
                    <div className="flex min-w-0 items-center gap-3">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-amber-300/15 bg-amber-300/[.08] text-sm font-bold text-amber-200">{user.name.charAt(0).toUpperCase()}</div>
                      <div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><h3 className="truncate font-semibold text-amber-50">{user.name}</h3>{user.role === "admin" && <Badge className="border border-amber-300/15 bg-amber-300/[.08] text-[10px] text-amber-200">Admin</Badge>}{user.role === "assistant" && <Badge variant="secondary" className="text-[10px]">Assistant</Badge>}</div><p className="truncate text-sm text-slate-400">{user.email}</p><div className="mt-1 flex flex-wrap gap-x-3 text-[11px] text-slate-500"><span>Joined {new Date(user.createdAt).toLocaleDateString("en-BD")}</span>{user.phone && <span>{user.phone}</span>}</div></div>
                    </div>
                    <div className="flex flex-wrap items-center justify-between gap-3 sm:justify-end">
                      <div className="grid grid-cols-2 gap-x-5 gap-y-1 text-right">
                        <div><p className="text-[10px] uppercase tracking-wider text-slate-500">Main</p><p className="font-mono text-sm font-semibold text-amber-300" data-testid={`text-user-main-balance-${user.id}`}>{money(user.balance)}</p></div>
                        <div><p className="text-[10px] uppercase tracking-wider text-slate-500">Investment</p><p className="font-mono text-sm font-semibold text-sky-300">{money(user.investmentBalance)}</p></div>
                      </div>
                      <Button variant={adjustingUserId === user.id ? "secondary" : "outline"} size="sm" onClick={() => setAdjustingUserId((current) => current === user.id ? null : user.id)} data-testid={`button-adjust-user-${user.id}`}>{adjustingUserId === user.id ? "Close form" : "Adjust balance"}</Button>
                    </div>
                  </div>
                  {adjustingUserId === user.id && <UserAdjustmentForm user={user} onClose={() => setAdjustingUserId(null)} />}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}