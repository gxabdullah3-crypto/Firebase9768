import { useState } from "react";
import {
  useListSubmissions,
  useApproveSubmission,
  useRejectSubmission,
  getListSubmissionsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, XCircle, Eye } from "lucide-react";

export default function AdminSubmissions() {
  const [location] = useLocation();
  const queryClient = useQueryClient();
  const { data: submissions, isLoading, isError, refetch } = useListSubmissions(undefined, {
    query: {
      queryKey: getListSubmissionsQueryKey(),
      refetchInterval: 10000,
      refetchOnWindowFocus: true,
    },
  });
  const approve = useApproveSubmission();
  const reject = useRejectSubmission();
  const { toast } = useToast();

  const [rejectId, setRejectId] = useState<number | null>(null);
  const [reason, setReason] = useState("");
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const invalidate = () => queryClient.invalidateQueries({ queryKey: getListSubmissionsQueryKey() });

  const handleApprove = (id: number) => {
    approve.mutate(
      { id },
      {
        onSuccess: () => {
          toast({ title: "অনুমোদিত হয়েছে", description: "ইউজারের ব্যালেন্সে টাকা যোগ হয়েছে।" });
          invalidate();
        },
        onError: (err: unknown) => {
          const apiError = err as { data?: { error?: string }; response?: { data?: { error?: string } } };
          const msg = apiError.data?.error || apiError.response?.data?.error || "অনুমোদন ব্যর্থ হয়েছে";
          toast({ title: "ব্যর্থ", description: msg, variant: "destructive" });
        },
      }
    );
  };

  const handleReject = () => {
    if (!rejectId || !reason.trim()) return;
    reject.mutate(
      { id: rejectId, data: { reason: reason.trim() } },
      {
        onSuccess: () => {
          toast({ title: "প্রত্যাখ্যান করা হয়েছে" });
          setRejectId(null);
          setReason("");
          invalidate();
        },
        onError: (error: unknown) => {
          const apiError = error as { data?: { error?: string }; response?: { data?: { error?: string } } };
          toast({
            title: "ব্যর্থ হয়েছে",
            description: apiError.data?.error || apiError.response?.data?.error || "আবার চেষ্টা করুন।",
            variant: "destructive",
          });
        },
      }
    );
  };

  const pending = submissions?.filter((s) => s.status === "pending") ?? [];
  const reviewed = submissions?.filter((s) => s.status !== "pending") ?? [];

  const SubmissionCard = ({ sub }: { sub: NonNullable<typeof submissions>[number] }) => (
    <Card key={sub.id} data-testid={`submission-card-${sub.id}`}>
      <CardContent className="p-4">
        <div className="flex flex-col md:flex-row gap-4 justify-between">
          <div className="space-y-2 flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <h3 className="font-bold text-base">{sub.task?.title || `টাস্ক #${sub.taskId}`}</h3>
              <Badge
                variant={
                  sub.status === "pending"
                    ? "secondary"
                    : sub.status === "approved"
                    ? "default"
                    : "destructive"
                }
              >
                {sub.status === "pending" ? "অপেক্ষমান" : sub.status === "approved" ? "অনুমোদিত" : "প্রত্যাখ্যাত"}
              </Badge>
            </div>

            <div className="text-sm text-muted-foreground space-y-0.5">
              <p>ইউজার: <span className="font-medium text-foreground">{sub.user?.name}</span> ({sub.user?.email})</p>
              <p>পুরস্কার: <span className="font-semibold text-primary">৳{sub.task?.reward}</span></p>
              <p>তারিখ: {new Date(sub.createdAt).toLocaleDateString("bn-BD")}</p>
            </div>

            <div className="rounded-md bg-muted p-3 text-sm mt-2">
              <p className="font-medium mb-1 text-xs text-muted-foreground">ইউজারের বিবরণ:</p>
              <p className="whitespace-pre-wrap">{sub.description}</p>
            </div>

            {sub.rejectionReason && (
              <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">
                <span className="font-medium">কারণ: </span>{sub.rejectionReason}
              </div>
            )}

            <Button
              data-testid={`button-view-screenshot-${sub.id}`}
              variant="outline"
              size="sm"
              className="gap-2 mt-1"
              onClick={() => setPreviewUrl(sub.screenshotUrl)}
            >
              <Eye className="h-4 w-4" />
              স্ক্রিনশট দেখুন
            </Button>
          </div>

          {sub.status === "pending" && (
            <div className="flex flex-row md:flex-col gap-2 md:min-w-[130px]">
              <Button
                data-testid={`button-approve-${sub.id}`}
                className="flex-1 gap-2 bg-green-600 hover:bg-green-700 text-white"
                onClick={() => handleApprove(sub.id)}
                disabled={approve.isPending}
              >
                <CheckCircle className="h-4 w-4" />
                অনুমোদন
              </Button>
              <Button
                data-testid={`button-reject-${sub.id}`}
                variant="destructive"
                className="flex-1 gap-2"
                onClick={() => { setRejectId(sub.id); setReason(""); }}
              >
                <XCircle className="h-4 w-4" />
                প্রত্যাখ্যান
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">সাবমিশন রিভিউ</h1>
        <p className="text-muted-foreground mt-1">
          {location.startsWith("/assistant/")
            ? "আপনার তৈরি টাস্কে জমা পড়া কাজ অনুমোদন বা প্রত্যাখ্যান করুন।"
            : "ইউজারদের জমা দেওয়া কাজ অনুমোদন বা প্রত্যাখ্যান করুন।"}
        </p>
      </div>

      {/* Screenshot Preview Dialog */}
      <Dialog open={!!previewUrl} onOpenChange={(o) => !o && setPreviewUrl(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>স্ক্রিনশট প্রমাণ</DialogTitle>
          </DialogHeader>
          {previewUrl && (
            <div className="mt-2">
              <img
                src={previewUrl}
                alt="Screenshot proof"
                className="w-full rounded-lg border object-contain max-h-[70vh]"
              />
              <a
                href={previewUrl}
                target="_blank"
                rel="noreferrer"
                className="mt-2 block text-center text-sm text-primary hover:underline"
              >
                নতুন ট্যাবে খুলুন
              </a>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Rejection Dialog */}
      <Dialog open={!!rejectId} onOpenChange={(o) => !o && setRejectId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>প্রত্যাখ্যানের কারণ</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <Textarea
              data-testid="input-reject-reason"
              placeholder="কেন প্রত্যাখ্যান করছেন তা লিখুন..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={4}
            />
            <Button
              data-testid="button-confirm-reject"
              variant="destructive"
              onClick={handleReject}
              className="w-full"
              disabled={!reason.trim() || reject.isPending}
            >
              {reject.isPending ? "প্রত্যাখ্যান হচ্ছে..." : "নিশ্চিত করুন"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Tabs defaultValue="pending">
        {isLoading ? (
          <div className="py-12 text-center text-muted-foreground rounded-lg border bg-card">
            সাবমিশন লোড হচ্ছে...
          </div>
        ) : isError ? (
          <div className="py-12 text-center rounded-lg border bg-card space-y-3">
            <p className="text-destructive">সাবমিশন লোড করা যায়নি।</p>
            <Button variant="outline" size="sm" onClick={() => refetch()}>
              আবার চেষ্টা করুন
            </Button>
          </div>
        ) : (
          <>
            <TabsList>
              <TabsTrigger value="pending" data-testid="tab-pending">
                অপেক্ষমান ({pending.length})
              </TabsTrigger>
              <TabsTrigger value="reviewed" data-testid="tab-reviewed">
                রিভিউ হয়েছে ({reviewed.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="pending" className="space-y-4 mt-4">
              {pending.length === 0 ? (
                <div className="py-12 text-center text-muted-foreground rounded-lg border bg-card">
                  কোনো অপেক্ষমান সাবমিশন নেই।
                </div>
              ) : (
                pending.map((sub) => <SubmissionCard key={sub.id} sub={sub} />)
              )}
            </TabsContent>

            <TabsContent value="reviewed" className="space-y-4 mt-4">
              {reviewed.length === 0 ? (
                <div className="py-12 text-center text-muted-foreground rounded-lg border bg-card">
                  এখনো কোনো রিভিউ নেই।
                </div>
              ) : (
                reviewed.map((sub) => <SubmissionCard key={sub.id} sub={sub} />)
              )}
            </TabsContent>
          </>
        )}
      </Tabs>
    </div>
  );
}
