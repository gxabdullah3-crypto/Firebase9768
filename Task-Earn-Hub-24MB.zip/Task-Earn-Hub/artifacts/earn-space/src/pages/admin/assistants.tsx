import { useState } from "react";
import {
  useListAssistants,
  useListUsers,
  useAssignAssistant,
  useRemoveAssistant,
  useGetAssistantActivity,
  getListAssistantsQueryKey,
  getListUsersQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  UserCog,
  UserPlus,
  UserMinus,
  ClipboardList,
  CheckCircle2,
  XCircle,
  Activity,
  BarChart3,
  ShieldCheck,
} from "lucide-react";

const activityLabels: Record<string, string> = {
  task_created: "নতুন টাস্ক তৈরি করেছেন",
  task_updated: "টাস্ক আপডেট করেছেন",
  task_deleted: "টাস্ক মুছে ফেলেছেন",
  submission_approved: "সাবমিশন অনুমোদন করেছেন",
  submission_rejected: "সাবমিশন প্রত্যাখ্যান করেছেন",
};

export default function AdminAssistants() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data, isLoading } = useListAssistants();
  const { data: users } = useListUsers();
  const assignAssistant = useAssignAssistant();
  const removeAssistant = useRemoveAssistant();
  const [selectedUser, setSelectedUser] = useState("");
  const [selectedAssistantId, setSelectedAssistantId] = useState<number | null>(null);
  const {
    data: activity,
    isLoading: activityLoading,
    isError: activityError,
    refetch: refetchActivity,
  } = useGetAssistantActivity(selectedAssistantId ?? 0);

  const availableUsers = users?.filter((user) => user.role === "user") ?? [];
  const assistants = data?.assistants ?? [];

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: getListAssistantsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
  };

  const handleAssign = () => {
    const userId = Number(selectedUser);
    if (!userId) return;
    assignAssistant.mutate(
      { userId },
      {
        onSuccess: () => {
          toast({ title: "Assistant যোগ হয়েছে", description: "এই user এখন নিজের task ও submission manage করতে পারবেন।" });
          setSelectedUser("");
          invalidate();
        },
        onError: (error: unknown) => {
          const apiError = error as { data?: { error?: string }; response?: { data?: { error?: string } } };
          const message = apiError.data?.error || apiError.response?.data?.error;
          toast({ title: "যোগ করা যায়নি", description: message || "আবার চেষ্টা করুন।", variant: "destructive" });
        },
      },
    );
  };

  const handleRemove = (userId: number) => {
    if (!window.confirm("এই user-এর Assistant role সরিয়ে দেবেন?")) return;
    removeAssistant.mutate(
      { userId },
      {
        onSuccess: () => {
          toast({ title: "Assistant role সরানো হয়েছে" });
          if (selectedAssistantId === userId) setSelectedAssistantId(null);
          invalidate();
        },
        onError: (error: unknown) => {
          const apiError = error as { data?: { error?: string }; response?: { data?: { error?: string } } };
          toast({
            title: "সরানো যায়নি",
            description: apiError.data?.error || apiError.response?.data?.error || "আবার চেষ্টা করুন।",
            variant: "destructive",
          });
        },
      },
    );
  };

  return (
    <div className="space-y-6 pb-6">
      <div>
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
            <UserCog className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Assistant Management</h1>
            <p className="text-sm text-muted-foreground mt-1">Assistant-দের permission, কাজ এবং activity নিয়ন্ত্রণ করুন।</p>
          </div>
        </div>
      </div>

      {/* Overview */}
      <div className="grid gap-3 sm:grid-cols-3">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <UserCog className="h-5 w-5 text-primary" />
            <div>
              <p className="text-2xl font-bold">{assistants.length}</p>
              <p className="text-xs text-muted-foreground">মোট Assistant</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <CheckCircle2 className="h-5 w-5 text-emerald-400" />
            <div>
              <p className="text-2xl font-bold">{data?.todayCompletedTasks ?? 0}</p>
              <p className="text-xs text-muted-foreground">আজকের completed task</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <ShieldCheck className="h-5 w-5 text-blue-400" />
            <div>
              <p className="text-sm font-semibold">সীমিত permission</p>
              <p className="text-xs text-muted-foreground">Assistant শুধু নিজের task পরিচালনা করে</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Assign */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <UserPlus className="h-4 w-4 text-primary" />
            নতুন Assistant যোগ করুন
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col sm:flex-row gap-3">
          <Select value={selectedUser} onValueChange={setSelectedUser}>
            <SelectTrigger className="flex-1" data-testid="select-assistant-user">
              <SelectValue placeholder="একজন user নির্বাচন করুন" />
            </SelectTrigger>
            <SelectContent>
              {availableUsers.length === 0 ? (
                <SelectItem value="none" disabled>নতুন user নেই</SelectItem>
              ) : (
                availableUsers.map((user) => (
                  <SelectItem key={user.id} value={String(user.id)}>
                    {user.name} — {user.email}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
          <Button
            onClick={handleAssign}
            disabled={!selectedUser || assignAssistant.isPending}
            className="gap-2"
            data-testid="button-assign-assistant"
          >
            <UserPlus className="h-4 w-4" />
            {assignAssistant.isPending ? "যোগ হচ্ছে..." : "Assistant করুন"}
          </Button>
        </CardContent>
      </Card>

      {/* Assistant list */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <BarChart3 className="h-4 w-4 text-primary" />
            সকল Assistant-এর পরিসংখ্যান
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="py-12 text-center text-muted-foreground">লোড হচ্ছে...</div>
          ) : assistants.length === 0 ? (
            <div className="py-12 text-center text-muted-foreground">
              এখনো কোনো Assistant যোগ করা হয়নি।
            </div>
          ) : (
            <div className="divide-y">
              {assistants.map((assistant) => (
                <div key={assistant.id} className="p-4 space-y-3" data-testid={`assistant-row-${assistant.id}`}>
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary font-bold">
                        {assistant.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-semibold truncate">{assistant.name}</p>
                          <Badge variant="default" className="text-[10px]">ASSISTANT</Badge>
                        </div>
                        <p className="text-xs text-muted-foreground truncate">{assistant.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-1.5"
                        onClick={() => setSelectedAssistantId(selectedAssistantId === assistant.id ? null : assistant.id)}
                        data-testid={`button-view-activity-${assistant.id}`}
                      >
                        <Activity className="h-3.5 w-3.5" />
                        Activity
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-1.5 text-destructive hover:text-destructive"
                        onClick={() => handleRemove(assistant.id)}
                        disabled={removeAssistant.isPending}
                        data-testid={`button-remove-assistant-${assistant.id}`}
                      >
                        <UserMinus className="h-3.5 w-3.5" />
                        Remove
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="rounded-lg bg-muted/50 p-2.5 text-center">
                      <ClipboardList className="h-4 w-4 mx-auto mb-1 text-primary" />
                      <p className="font-bold">{assistant.taskCount}</p>
                      <p className="text-[10px] text-muted-foreground">পোস্ট করা task</p>
                    </div>
                    <div className="rounded-lg bg-emerald-500/10 p-2.5 text-center">
                      <CheckCircle2 className="h-4 w-4 mx-auto mb-1 text-emerald-400" />
                      <p className="font-bold">{assistant.approvedCount}</p>
                      <p className="text-[10px] text-muted-foreground">Approved</p>
                    </div>
                    <div className="rounded-lg bg-red-500/10 p-2.5 text-center">
                      <XCircle className="h-4 w-4 mx-auto mb-1 text-red-400" />
                      <p className="font-bold">{assistant.rejectedCount}</p>
                      <p className="text-[10px] text-muted-foreground">Rejected</p>
                    </div>
                  </div>

                  {selectedAssistantId === assistant.id && (
                    <div className="rounded-xl border bg-muted/20 p-3">
                      <p className="text-xs font-semibold mb-2 flex items-center gap-1.5">
                        <Activity className="h-3.5 w-3.5 text-primary" />
                        সাম্প্রতিক activity
                      </p>
                      {activityLoading ? (
                        <p className="text-xs text-muted-foreground py-3 text-center">Activity লোড হচ্ছে...</p>
                      ) : activityError ? (
                        <div className="py-3 text-center space-y-2">
                          <p className="text-xs text-destructive">Activity লোড করা যায়নি।</p>
                          <Button variant="outline" size="sm" onClick={() => refetchActivity()}>আবার চেষ্টা করুন</Button>
                        </div>
                      ) : !activity || activity.length === 0 ? (
                        <p className="text-xs text-muted-foreground py-3 text-center">এখনো কোনো activity নেই।</p>
                      ) : (
                        <div className="space-y-2 max-h-64 overflow-y-auto">
                          {activity.map((item) => (
                            <div key={item.id} className="flex items-start justify-between gap-3 text-xs border-b last:border-0 pb-2 last:pb-0">
                              <div>
                                <p className="font-medium">{activityLabels[item.action] ?? item.action}</p>
                                {item.details && <p className="text-muted-foreground mt-0.5">{item.details}</p>}
                              </div>
                              <time className="text-muted-foreground whitespace-nowrap">
                                {new Date(item.createdAt).toLocaleString("bn-BD", { dateStyle: "short", timeStyle: "short" })}
                              </time>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}