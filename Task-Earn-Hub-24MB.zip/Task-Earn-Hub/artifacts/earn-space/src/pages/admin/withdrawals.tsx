import { useState } from "react";
import {
  useListWithdrawals,
  useApproveWithdrawal,
  useRejectWithdrawal,
  getListWithdrawalsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, XCircle } from "lucide-react";

export default function AdminWithdrawals() {
  const queryClient = useQueryClient();
  const { data: withdrawals } = useListWithdrawals();
  const approve = useApproveWithdrawal();
  const reject = useRejectWithdrawal();
  const { toast } = useToast();

  const [rejectId, setRejectId] = useState<number | null>(null);
  const [reason, setReason] = useState("");

  const invalidate = () => queryClient.invalidateQueries({ queryKey: getListWithdrawalsQueryKey() });

  const handleApprove = (id: number) => {
    approve.mutate(
      { id },
      {
        onSuccess: () => {
          toast({ title: "উইথড্রয়াল অনুমোদিত হয়েছে" });
          invalidate();
        },
        onError: () => toast({ title: "অনুমোদন ব্যর্থ হয়েছে", variant: "destructive" }),
      }
    );
  };

  const handleReject = () => {
    if (!rejectId || !reason.trim()) return;
    reject.mutate(
      { id: rejectId, data: { reason: reason.trim() } },
      {
        onSuccess: () => {
          toast({ title: "প্রত্যাখ্যান করা হয়েছে", description: "ব্যালেন্স ফেরত দেওয়া হয়েছে।" });
          setRejectId(null);
          setReason("");
          invalidate();
        },
        onError: () => toast({ title: "ব্যর্থ হয়েছে", variant: "destructive" }),
      }
    );
  };

  const pending = withdrawals?.filter((w) => w.status === "pending") ?? [];
  const reviewed = withdrawals?.filter((w) => w.status !== "pending") ?? [];

  const methodLabel = (m: string) => (m === "bkash" ? "bKash" : "Nagad");

  const WithdrawalCard = ({ w }: { w: NonNullable<typeof withdrawals>[number] }) => (
    <div
      key={w.id}
      data-testid={`withdrawal-row-${w.id}`}
      className="p-4 flex flex-col md:flex-row justify-between gap-4 md:items-center"
    >
      <div className="flex-1">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-bold text-xl text-primary">৳{w.amount}</span>
          <Badge
            className={
              w.method === "bkash"
                ? "bg-pink-100 text-pink-700 border-pink-200"
                : "bg-orange-100 text-orange-700 border-orange-200"
            }
            variant="outline"
          >
            {methodLabel(w.method)}
          </Badge>
          <Badge
            variant={
              w.status === "pending" ? "secondary" : w.status === "approved" ? "default" : "destructive"
            }
          >
            {w.status === "pending" ? "অপেক্ষমান" : w.status === "approved" ? "অনুমোদিত" : "প্রত্যাখ্যাত"}
          </Badge>
        </div>
        <div className="mt-1.5 text-sm text-muted-foreground space-y-0.5">
          <p>অ্যাকাউন্ট: <span className="font-mono font-medium text-foreground">{w.accountNumber}</span></p>
          <p>ইউজার: <span className="font-medium text-foreground">{w.user?.name}</span> ({w.user?.email})</p>
          <p>তারিখ: {new Date(w.createdAt).toLocaleDateString("bn-BD")}</p>
        </div>
        {w.rejectionReason && (
          <p className="mt-1.5 text-sm text-destructive">
            <span className="font-medium">কারণ: </span>{w.rejectionReason}
          </p>
        )}
      </div>

      {w.status === "pending" && (
        <div className="flex gap-2 flex-shrink-0">
          <Button
            data-testid={`button-approve-withdrawal-${w.id}`}
            className="gap-2 bg-green-600 hover:bg-green-700 text-white"
            onClick={() => handleApprove(w.id)}
            disabled={approve.isPending}
          >
            <CheckCircle className="h-4 w-4" />
            অনুমোদন
          </Button>
          <Button
            data-testid={`button-reject-withdrawal-${w.id}`}
            variant="destructive"
            className="gap-2"
            onClick={() => { setRejectId(w.id); setReason(""); }}
          >
            <XCircle className="h-4 w-4" />
            প্রত্যাখ্যান
          </Button>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">উইথড্রয়াল রিকোয়েস্ট</h1>
        <p className="text-muted-foreground mt-1">ইউজারদের উইথড্রয়াল অনুরোধ পরিচালনা করুন।</p>
      </div>

      {/* Rejection Dialog */}
      <Dialog open={!!rejectId} onOpenChange={(o) => !o && setRejectId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>প্রত্যাখ্যানের কারণ</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <Textarea
              data-testid="input-reject-reason"
              placeholder="কেন প্রত্যাখ্যান করছেন তা লিখুন..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={3}
            />
            <p className="text-xs text-muted-foreground">প্রত্যাখ্যান করলে ইউজারের ব্যালেন্সে টাকা ফেরত যাবে।</p>
            <Button
              data-testid="button-confirm-reject"
              variant="destructive"
              onClick={handleReject}
              className="w-full"
              disabled={!reason.trim() || reject.isPending}
            >
              {reject.isPending ? "প্রত্যাখ্যান হচ্ছে..." : "নিশ্চিত করুন"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Tabs defaultValue="pending">
        <TabsList>
          <TabsTrigger value="pending" data-testid="tab-pending">
            অপেক্ষমান ({pending.length})
          </TabsTrigger>
          <TabsTrigger value="reviewed" data-testid="tab-reviewed">
            সম্পন্ন ({reviewed.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="mt-4">
          <Card>
            <CardContent className="p-0">
              {pending.length === 0 ? (
                <div className="py-12 text-center text-muted-foreground">কোনো অপেক্ষমান রিকোয়েস্ট নেই।</div>
              ) : (
                <div className="divide-y">
                  {pending.map((w) => <WithdrawalCard key={w.id} w={w} />)}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reviewed" className="mt-4">
          <Card>
            <CardContent className="p-0">
              {reviewed.length === 0 ? (
                <div className="py-12 text-center text-muted-foreground">কোনো সম্পন্ন রিকোয়েস্ট নেই।</div>
              ) : (
                <div className="divide-y">
                  {reviewed.map((w) => <WithdrawalCard key={w.id} w={w} />)}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
