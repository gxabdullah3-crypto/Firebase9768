import { useState } from "react";
import { useParams, useLocation } from "wouter";
import {
  useGetTask,
  useCreateSubmission,
  getGetTaskQueryKey,
  getListSubmissionsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { ExternalLink } from "lucide-react";

export default function TaskDetail() {
  const { id } = useParams<{ id: string }>();
  const taskId = parseInt(id || "0");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: task, isLoading } = useGetTask(taskId, {
    query: { enabled: !!taskId, queryKey: getGetTaskQueryKey(taskId) },
  });

  const createSubmission = useCreateSubmission();

  const [file, setFile] = useState<File | null>(null);
  const [description, setDescription] = useState("");
  const [isUploading, setIsUploading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0] || null;
    if (selected && selected.size > 10 * 1024 * 1024) {
      toast({ title: "ফাইল অনেক বড়", description: "সর্বোচ্চ ১০MB এর ছবি দিন।", variant: "destructive" });
      e.target.value = "";
      return;
    }
    setFile(selected);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      toast({ title: "স্ক্রিনশট দিন", description: "অনুগ্রহ করে একটি স্ক্রিনশট যোগ করুন।", variant: "destructive" });
      return;
    }
    if (!description.trim()) {
      toast({ title: "বিবরণ দিন", description: "কাজের বিবরণ লিখুন।", variant: "destructive" });
      return;
    }

    try {
      setIsUploading(true);
      const formData = new FormData();
      formData.append("file", file);

      const uploadRes = await fetch("/api/upload/screenshot", {
        method: "POST",
        credentials: "include",
        body: formData,
      });

      if (!uploadRes.ok) {
        const err = await uploadRes.json().catch(() => ({}));
        throw new Error(err.error || "আপলোড ব্যর্থ হয়েছে");
      }

      const { url } = await uploadRes.json();

      await createSubmission.mutateAsync({
        data: { taskId, screenshotUrl: url, description: description.trim() },
      });

      await queryClient.invalidateQueries({ queryKey: getListSubmissionsQueryKey() });

      toast({ title: "সফল!", description: "কাজ সফলভাবে জমা হয়েছে!" });
      setLocation("/submissions");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "কাজ জমা দিতে সমস্যা হয়েছে।";
      toast({ title: "ব্যর্থ", description: msg, variant: "destructive" });
    } finally {
      setIsUploading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-48">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    );
  }
  if (!task) return <div className="text-center p-8 text-muted-foreground">কাজ পাওয়া যায়নি।</div>;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start gap-4">
            <div>
              <CardTitle className="text-2xl">{task.title}</CardTitle>
              <div className="mt-2 flex items-center gap-3">
                <Badge className="text-base px-3 py-1 bg-primary text-primary-foreground">
                  পুরস্কার: ৳{task.reward}
                </Badge>
                <Badge variant={task.status === "active" ? "default" : "secondary"}>
                  {task.status === "active" ? "সক্রিয়" : "নিষ্ক্রিয়"}
                </Badge>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-lg bg-muted/50 p-4">
            <p className="whitespace-pre-wrap text-sm leading-relaxed">{task.description}</p>
          </div>

          {task.link && (
            <div className="mt-4 border rounded-lg overflow-hidden">
              <div className="bg-muted px-3 py-2 flex items-center gap-2 text-sm border-b">
                <ExternalLink className="h-4 w-4 text-primary flex-shrink-0" />
                <a
                  href={task.link}
                  target="_blank"
                  rel="noreferrer"
                  className="text-primary hover:underline truncate font-medium"
                >
                  {task.link}
                </a>
              </div>
              <div className="w-full" style={{ height: "70vh", minHeight: "500px" }}>
                <iframe
                  src={task.link}
                  className="w-full h-full border-0"
                  sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                  title="Task link"
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>প্রমাণ জমা দিন</CardTitle>
          <CardDescription>স্ক্রিনশট এবং বিবরণ দিয়ে পুরস্কার দাবি করুন।</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="screenshot">স্ক্রিনশট (গ্যালারি থেকে বেছে নিন)</Label>
              <Input
                data-testid="input-screenshot"
                id="screenshot"
                type="file"
                accept="image/*"
                capture={undefined}
                onChange={handleFileChange}
                className="cursor-pointer"
              />
              <p className="text-xs text-muted-foreground">শুধু ছবি ফাইল, সর্বোচ্চ ১০MB</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">বিবরণ লিখুন</Label>
              <Textarea
                data-testid="input-description"
                id="description"
                placeholder="কাজটি কীভাবে করেছেন তার বিস্তারিত লিখুন..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                required
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button
              data-testid="button-submit"
              type="submit"
              className="w-full"
              disabled={isUploading || createSubmission.isPending || !file || !description.trim()}
            >
              {isUploading || createSubmission.isPending ? "জমা হচ্ছে..." : "কাজ জমা দিন"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
