import { useGetMe, useListTasks, useListSubmissions } from "@workspace/api-client-react";
import { Link } from "wouter";
import {
  ArrowRight,
  CheckSquare,
  ClipboardList,
  Wallet,
  TrendingUp,
} from "lucide-react";

const money = (amount: number) =>
  `৳${Number(amount ?? 0).toLocaleString("en-BD", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export default function Dashboard() {
  const { data: user } = useGetMe();
  const { data: tasks } = useListTasks({ status: "active" });
  const { data: submissions } = useListSubmissions();

  const approved = submissions?.filter((submission) => submission.status === "approved").length ?? 0;
  const pending = submissions?.filter((submission) => submission.status === "pending").length ?? 0;
  const totalEarned = submissions
    ?.filter((submission) => submission.status === "approved")
    .reduce((total, submission) => total + (submission.task?.reward ?? 0), 0) ?? 0;

  const statusLabel = (status: string) =>
    status === "approved" ? "অনুমোদিত" : status === "rejected" ? "প্রত্যাখ্যাত" : "অপেক্ষমান";

  return (
    <div className="mx-auto max-w-7xl space-y-5 pb-8" data-testid="page-dashboard">
      <section className="dashboard-hero">
        <div className="dashboard-hero-content">
          <div className="min-w-0">
            <div className="dashboard-welcome-label">
              <span className={`h-1.5 w-1.5 rounded-full ${user?.status === "active" ? "bg-emerald-400" : "bg-rose-400"}`} />
              {user?.status === "active" ? "আপনার অ্যাকাউন্ট সক্রিয়" : "অ্যাকাউন্টের অবস্থা"}
            </div>
            <h2>স্বাগতম, {user?.name || "Earn Space-এ"}</h2>
            <p className="dashboard-hero-copy">আজকের অগ্রগতি দেখুন এবং আপনার পরবর্তী কাজটি বেছে নিন।</p>
          </div>

          <div className="dashboard-balance" data-testid="text-wallet-balance">
            <span className="dashboard-metric-label">উপলভ্য ব্যালেন্স</span>
            <strong>{money(user?.balance ?? 0)}</strong>
            <Link href="/withdraw">
              <span className="mt-2 inline-flex cursor-pointer items-center gap-1.5 text-xs font-medium text-primary hover:text-[var(--gold-bright)]">
                টাকা তুলুন <ArrowRight className="h-3.5 w-3.5" />
              </span>
            </Link>
          </div>
        </div>
      </section>

      <section className="dashboard-stat-grid" aria-label="আপনার সারাংশ">
        {[
          { icon: CheckSquare, value: tasks?.length ?? 0, label: "সক্রিয় টাস্ক", tone: "blue" },
          { icon: ClipboardList, value: pending, label: "অপেক্ষমান সাবমিশন", tone: "gold" },
          { icon: TrendingUp, value: approved, label: "অনুমোদিত সাবমিশন", tone: "green" },
        ].map(({ icon: Icon, value, label, tone }) => (
          <article key={label} className="dashboard-stat-card" data-tone={tone} data-testid={`stat-${tone}`}>
            <div className="dashboard-stat-icon"><Icon className="h-[18px] w-[18px]" strokeWidth={1.8} /></div>
            <p className="dashboard-stat-value">{value}</p>
            <p className="dashboard-stat-label">{label}</p>
          </article>
        ))}
      </section>

      {totalEarned > 0 && (
        <section className="flex items-center gap-3 rounded-2xl border border-emerald-400/15 bg-emerald-400/[.045] p-4" data-testid="text-total-earned">
          <span className="grid h-10 w-10 flex-none place-items-center rounded-xl bg-emerald-400/10 text-emerald-300">
            <Wallet className="h-5 w-5" />
          </span>
          <span>
            <span className="block text-xs text-emerald-200/70">মোট অনুমোদিত আয়</span>
            <strong className="mt-0.5 block text-lg font-semibold tracking-tight text-emerald-200">{money(totalEarned)}</strong>
          </span>
        </section>
      )}

      <section>
        <p className="dashboard-section-label">দ্রুত অ্যাকশন</p>
        <div className="grid gap-3 sm:grid-cols-2">
          <Link href="/tasks">
            <div className="dashboard-action group cursor-pointer" data-testid="link-dashboard-tasks">
              <span className="grid h-10 w-10 flex-none place-items-center rounded-xl border border-primary/15 bg-primary/[.08] text-primary">
                <CheckSquare className="h-5 w-5" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold">টাস্ক করুন</span>
                <span className="mt-0.5 block text-xs text-muted-foreground">নতুন কাজ দেখে শুরু করুন</span>
              </span>
              <ArrowRight className="h-4 w-4 flex-none text-muted-foreground transition-transform group-hover:translate-x-1" />
            </div>
          </Link>
          <Link href="/investments">
            <div className="dashboard-action group cursor-pointer" data-testid="link-dashboard-investments">
              <span className="grid h-10 w-10 flex-none place-items-center rounded-xl border border-primary/15 bg-primary/[.08] text-primary">
                <TrendingUp className="h-5 w-5" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold">ইনভেস্টমেন্ট</span>
                <span className="mt-0.5 block text-xs text-muted-foreground">চলমান প্ল্যান দেখুন</span>
              </span>
              <ArrowRight className="h-4 w-4 flex-none text-muted-foreground" />
            </div>
          </Link>
        </div>
      </section>

      <div className="grid gap-4 xl:grid-cols-2">
        <section className="dashboard-panel">
          <div className="dashboard-panel-header">
            <h2 className="text-sm font-semibold">সাম্প্রতিক টাস্ক</h2>
            <Link href="/tasks">
              <span className="inline-flex cursor-pointer items-center gap-1 text-xs font-medium text-primary hover:text-[var(--gold-bright)]" data-testid="link-all-tasks">
                সব দেখুন <ArrowRight className="h-3.5 w-3.5" />
              </span>
            </Link>
          </div>
          <div>
            {tasks?.slice(0, 4).map((task) => (
              <Link key={task.id} href={`/tasks/${task.id}`}>
                <div className="dashboard-panel-row cursor-pointer" data-testid={`dashboard-task-${task.id}`}>
                  <span className="grid h-9 w-9 flex-none place-items-center rounded-xl border border-primary/10 bg-primary/[.06] text-primary">
                    <CheckSquare className="h-4 w-4" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-medium">{task.title}</span>
                    <span className="mt-0.5 block truncate text-xs text-muted-foreground">{task.description}</span>
                  </span>
                  <span className="flex-none text-right">
                    <span className="block text-sm font-semibold text-primary">{money(task.reward)}</span>
                    <ArrowRight className="ml-auto mt-1 h-3.5 w-3.5 text-muted-foreground" />
                  </span>
                </div>
              </Link>
            ))}
            {(!tasks || tasks.length === 0) && (
              <div className="px-5 py-9 text-center text-sm text-muted-foreground">
                <CheckSquare className="mx-auto mb-2 h-7 w-7 opacity-35" />
                এখন কোনো সক্রিয় টাস্ক নেই।
              </div>
            )}
          </div>
        </section>

        <section className="dashboard-panel">
          <div className="dashboard-panel-header">
            <h2 className="text-sm font-semibold">সাম্প্রতিক সাবমিশন</h2>
            <Link href="/submissions">
              <span className="inline-flex cursor-pointer items-center gap-1 text-xs font-medium text-primary hover:text-[var(--gold-bright)]" data-testid="link-all-submissions">
                সব দেখুন <ArrowRight className="h-3.5 w-3.5" />
              </span>
            </Link>
          </div>
          <div>
            {submissions?.slice(0, 4).map((submission) => (
              <div key={submission.id} className="dashboard-panel-row" data-testid={`dashboard-submission-${submission.id}`}>
                <span className="grid h-9 w-9 flex-none place-items-center rounded-xl border border-white/[.06] bg-white/[.025] text-muted-foreground">
                  <ClipboardList className="h-4 w-4" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium">{submission.task?.title || `টাস্ক #${submission.taskId}`}</span>
                  <span className="mt-0.5 block text-xs text-muted-foreground">
                    {new Date(submission.createdAt).toLocaleDateString("bn-BD")}
                  </span>
                </span>
                <span
                  className={`flex-none rounded-full border px-2.5 py-1 text-[11px] font-medium ${
                    submission.status === "approved"
                      ? "border-emerald-300/15 bg-emerald-300/[.06] text-emerald-200"
                      : submission.status === "rejected"
                      ? "border-rose-300/15 bg-rose-300/[.06] text-rose-200"
                      : "border-primary/15 bg-primary/[.06] text-primary"
                  }`}
                >
                  {statusLabel(submission.status)}
                </span>
              </div>
            ))}
            {(!submissions || submissions.length === 0) && (
              <div className="px-5 py-9 text-center text-sm text-muted-foreground">
                <ClipboardList className="mx-auto mb-2 h-7 w-7 opacity-35" />
                এখনো কোনো কাজ জমা দেননি।
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}