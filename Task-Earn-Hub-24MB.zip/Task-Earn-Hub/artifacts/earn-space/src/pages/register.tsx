import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link, useLocation, useSearch } from "wouter";
import { useRegister, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowRight, Gift, LoaderCircle, Lock, Mail, Phone, User, type LucideIcon } from "lucide-react";
import { AuthShell } from "@/components/auth-shell";

const registerSchema = z.object({
  name: z.string().min(2, "নাম কমপক্ষে ২ অক্ষর হতে হবে"),
  email: z.string().email("সঠিক ইমেইল লিখুন"),
  password: z.string().min(6, "পাসওয়ার্ড কমপক্ষে ৬ অক্ষর হতে হবে"),
  phone: z.string().optional(),
  referralCode: z.string().optional(),
});

type RegisterForm = z.infer<typeof registerSchema>;

const fields: {
  name: keyof RegisterForm;
  label: string;
  type: string;
  placeholder: string;
  icon: LucideIcon;
  autoComplete: string;
  required?: boolean;
}[] = [
  { name: "name", label: "পুরো নাম", type: "text", placeholder: "আপনার নাম", icon: User, autoComplete: "name", required: true },
  { name: "email", label: "ইমেইল", type: "email", placeholder: "name@example.com", icon: Mail, autoComplete: "email", required: true },
  { name: "password", label: "পাসওয়ার্ড", type: "password", placeholder: "কমপক্ষে ৬ অক্ষর", icon: Lock, autoComplete: "new-password", required: true },
  { name: "phone", label: "ফোন নম্বর (ঐচ্ছিক)", type: "tel", placeholder: "01XXXXXXXXX", icon: Phone, autoComplete: "tel" },
  { name: "referralCode", label: "রেফারেল কোড (ঐচ্ছিক)", type: "text", placeholder: "XXXX1234", icon: Gift, autoComplete: "off" },
];

export default function Register() {
  const [, setLocation] = useLocation();
  const search = useSearch();
  const queryClient = useQueryClient();
  const register = useRegister();
  const refFromUrl = new URLSearchParams(search).get("ref") ?? "";
  const form = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
    defaultValues: { name: "", email: "", password: "", phone: "", referralCode: refFromUrl },
  });

  const onSubmit = (data: RegisterForm) => {
    register.mutate(
      {
        data: {
          name: data.name,
          email: data.email,
          password: data.password,
          phone: data.phone || undefined,
          referralCode: data.referralCode || undefined,
        },
      },
      {
        onSuccess: (user) => {
          queryClient.setQueryData(getGetMeQueryKey(), user);
          setLocation(user.role === "admin" ? "/admin" : "/dashboard");
        },
        onError: () => {
          form.setError("root", {
            message: "রেজিস্ট্রেশন ব্যর্থ হয়েছে। ইমেইলটি ইতিমধ্যে ব্যবহৃত হতে পারে।",
          });
        },
      },
    );
  };

  return (
    <AuthShell title="আপনার অ্যাকাউন্ট তৈরি করুন" description="কয়েকটি তথ্য দিয়ে Earn Space-এ যোগ দিন।">
      <form onSubmit={form.handleSubmit(onSubmit)} className="auth-form" data-testid="form-register">
        {fields.map(({ name, label, type, placeholder, icon: Icon, autoComplete, required }) => {
          const error = form.formState.errors[name];
          const inputId = `register-${name}`;
          const errorId = `${inputId}-error`;
          return (
            <div key={name} className="auth-field">
              <label className="auth-label" htmlFor={inputId}>{label}</label>
              <div className="auth-input-wrap">
                <Icon className="auth-field-icon h-[17px] w-[17px]" aria-hidden="true" />
                <input
                  id={inputId}
                  data-testid={`input-${name}`}
                  type={type}
                  autoComplete={autoComplete}
                  placeholder={placeholder}
                  required={required}
                  className="auth-input"
                  aria-invalid={!!error}
                  aria-describedby={error ? errorId : undefined}
                  {...form.register(name)}
                />
              </div>
              {error && (
                <p className="auth-error" id={errorId} role="alert">{error.message as string}</p>
              )}
            </div>
          );
        })}

        {form.formState.errors.root && (
          <div className="auth-alert" role="alert">{form.formState.errors.root.message}</div>
        )}

        <button data-testid="button-register" type="submit" className="auth-submit" disabled={register.isPending}>
          {register.isPending ? (
            <><LoaderCircle className="h-4 w-4 animate-spin" /> রেজিস্ট্রেশন হচ্ছে...</>
          ) : (
            <>অ্যাকাউন্ট তৈরি করুন <ArrowRight className="h-4 w-4" /></>
          )}
        </button>
      </form>

      <p className="auth-switch">
        ইতিমধ্যে অ্যাকাউন্ট আছে?{" "}
        <Link href="/login">
          <span className="auth-link cursor-pointer" data-testid="link-login">লগইন করুন</span>
        </Link>
      </p>
    </AuthShell>
  );
}