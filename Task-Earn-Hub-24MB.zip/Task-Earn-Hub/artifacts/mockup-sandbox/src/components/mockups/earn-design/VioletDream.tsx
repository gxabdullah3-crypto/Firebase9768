import React, { useState } from 'react';

export default function VioletDream() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);

  return (
    <div className="flex justify-center bg-[#07020F] min-h-screen" style={{ fontFamily: "'Poppins', 'Hind Siliguri', sans-serif" }}>
      <style dangerouslySetInnerHTML={{ __html: `
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap');

        @keyframes spin-cw {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
        @keyframes spin-ccw {
          from { transform: rotate(0deg); }
          to   { transform: rotate(-360deg); }
        }
        @keyframes pulse-glow {
          0%, 100% {
            transform: scale(1);
            box-shadow: 0 0 22px rgba(34,211,238,0.55), 0 0 44px rgba(167,139,250,0.30);
          }
          50% {
            transform: scale(1.07);
            box-shadow: 0 0 38px rgba(34,211,238,0.80), 0 0 70px rgba(167,139,250,0.50);
          }
        }
        @keyframes float-up {
          0%, 100% { transform: translateY(0px); }
          50%       { transform: translateY(-20px); }
        }
        @keyframes float-dn {
          0%, 100% { transform: translateY(0px); }
          50%       { transform: translateY(16px); }
        }
        @keyframes float-lr {
          0%, 100% { transform: translate(0px, 0px); }
          50%       { transform: translate(14px, -12px); }
        }
        @keyframes grad-pan {
          0%   { background-position: 0%   50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0%   50%; }
        }
        @keyframes shimmer {
          0%   { left: -100%; }
          100% { left: 200%; }
        }
        @keyframes fade-in-up {
          from { opacity: 0; transform: translateY(18px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes ring-pulse {
          0%, 100% { opacity: 0.6; }
          50%       { opacity: 1; }
        }

        .spin-cw-30  { animation: spin-cw  30s linear infinite; }
        .spin-ccw-20 { animation: spin-ccw 20s linear infinite; }
        .pulse-glow  { animation: pulse-glow 3s ease-in-out infinite; }
        .float-up    { animation: float-up 7s ease-in-out infinite; }
        .float-dn    { animation: float-dn 9s ease-in-out infinite; }
        .float-lr    { animation: float-lr 11s ease-in-out infinite; }
        .grad-pan    {
          background-size: 300% 300%;
          animation: grad-pan 4s ease infinite;
        }
        .fade-in-up  { animation: fade-in-up 0.7s ease both; }
        .ring-pulse  { animation: ring-pulse 2.5s ease-in-out infinite; }

        .btn-glow {
          box-shadow: 0 0 25px rgba(34,211,238,0.35), 0 4px 24px rgba(167,139,250,0.25);
          transition: box-shadow 0.3s ease, transform 0.3s ease;
        }
        .btn-glow:hover {
          box-shadow: 0 0 42px rgba(34,211,238,0.55), 0 8px 36px rgba(244,114,182,0.35);
          transform: translateY(-2px);
        }
        .input-field {
          transition: border-color 0.25s, box-shadow 0.25s, background 0.25s;
        }
        .input-field:focus {
          outline: none;
          border-color: rgba(34,211,238,0.45);
          box-shadow: 0 0 0 3px rgba(34,211,238,0.12);
          background: rgba(255,255,255,0.09);
        }
        .card-glass {
          box-shadow:
            inset 0 1px 0 rgba(255,255,255,0.09),
            0 24px 70px rgba(0,0,0,0.55),
            0 0 0 1px rgba(255,255,255,0.06);
        }
      `}} />

      <div className="relative w-full max-w-[390px] min-h-screen overflow-hidden flex flex-col" style={{ background: '#0D0618' }}>

        {/* ── Layered mesh background ── */}
        <div className="absolute inset-0 pointer-events-none" style={{
          background: `
            radial-gradient(ellipse 65% 45% at 8%  12%, rgba(34,211,238,0.18)  0%, transparent 70%),
            radial-gradient(ellipse 55% 50% at 92% 88%, rgba(244,114,182,0.18) 0%, transparent 70%),
            radial-gradient(ellipse 80% 65% at 50% 55%, rgba(167,139,250,0.11) 0%, transparent 70%)
          `
        }} />

        {/* Subtle dot grid */}
        <div className="absolute inset-0 pointer-events-none opacity-[0.35]" style={{
          backgroundImage: `
            linear-gradient(rgba(255,255,255,0.04) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.04) 1px, transparent 1px)
          `,
          backgroundSize: '36px 36px'
        }} />

        {/* Floating orbs */}
        <div className="absolute w-[240px] h-[240px] rounded-full float-up pointer-events-none"
          style={{ top: '-60px', left: '-70px', background: 'rgba(34,211,238,0.13)', filter: 'blur(72px)', animationDelay: '0s' }} />
        <div className="absolute w-[280px] h-[280px] rounded-full float-dn pointer-events-none"
          style={{ bottom: '-80px', right: '-70px', background: 'rgba(244,114,182,0.14)', filter: 'blur(90px)', animationDelay: '2s' }} />
        <div className="absolute w-[180px] h-[180px] rounded-full float-lr pointer-events-none"
          style={{ top: '42%', left: '55%', background: 'rgba(167,139,250,0.16)', filter: 'blur(70px)', animationDelay: '1s' }} />

        {/* ── Logo section ── */}
        <div className="flex flex-col items-center pt-14 pb-6 z-10 fade-in-up" style={{ animationDelay: '0.1s' }}>

          {/* Multi-ring logo */}
          <div className="relative w-[110px] h-[110px] flex items-center justify-center mb-5">

            {/* Outer spinning ring with 4 node dots */}
            <div className="spin-cw-30 ring-pulse absolute inset-0 rounded-full"
              style={{ border: '2px solid transparent', background: 'linear-gradient(#0D0618, #0D0618) padding-box, linear-gradient(135deg, #22D3EE, #A78BFA, #F472B6) border-box' }}>
              {/* Clock dots */}
              {[
                { top: '-5px',  left: '50%',  transform: 'translateX(-50%)' },
                { top: '50%',   right: '-5px', transform: 'translateY(-50%)' },
                { bottom: '-5px', left: '50%', transform: 'translateX(-50%)' },
                { top: '50%',   left: '-5px', transform: 'translateY(-50%)' },
              ].map((s, i) => (
                <div key={i} className="absolute w-[8px] h-[8px] rounded-full"
                  style={{ ...s, background: 'linear-gradient(135deg, #22D3EE, #A78BFA, #F472B6)', boxShadow: '0 0 6px rgba(34,211,238,0.8)' }} />
              ))}
            </div>

            {/* Middle counter-spin dashed ring */}
            <div className="spin-ccw-20 absolute rounded-full"
              style={{ inset: '12px', border: '1px dashed rgba(167,139,250,0.35)' }} />

            {/* Inner glowing diamond */}
            <div className="pulse-glow absolute rounded-[16px]"
              style={{
                inset: '22px',
                background: 'linear-gradient(135deg, #22D3EE, #A78BFA, #F472B6)',
                transform: 'rotate(45deg)',
              }} />

            {/* Center letter — stays static */}
            <div className="absolute z-10 flex items-center justify-center w-[30px] h-[30px]">
              <span style={{ fontSize: '20px', fontWeight: 900, color: '#fff', textShadow: '0 0 12px rgba(34,211,238,0.9)', lineHeight: 1 }}>E</span>
            </div>
          </div>

          {/* App name */}
          <h1 style={{
            fontSize: '34px',
            fontWeight: 900,
            letterSpacing: '-0.5px',
            background: 'linear-gradient(90deg, #22D3EE, #A78BFA, #F472B6)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            marginBottom: '6px',
            lineHeight: 1.1,
          }}>
            Earn Space
          </h1>

          {/* Bengali tagline */}
          <p style={{ color: 'rgba(255,255,255,0.40)', fontSize: '12px', letterSpacing: '2px', fontWeight: 500 }}>
            আয় করুন • স্বপ্ন ছুঁয়ে নিন
          </p>
        </div>

        {/* ── Form card ── */}
        <div className="px-5 pb-10 z-10 fade-in-up" style={{ animationDelay: '0.25s' }}>
          <div className="card-glass rounded-[28px] overflow-hidden"
            style={{ background: 'rgba(255,255,255,0.035)', backdropFilter: 'blur(28px)', border: '1px solid rgba(255,255,255,0.07)' }}>

            {/* Gradient top accent bar */}
            <div style={{ height: '3px', background: 'linear-gradient(90deg, #22D3EE, #A78BFA, #F472B6)' }} />

            <div className="p-7 flex flex-col gap-5">

              {/* Card header */}
              <div className="mb-1">
                <h2 style={{ color: '#fff', fontSize: '22px', fontWeight: 700, marginBottom: '4px' }}>স্বাগতম 👋</h2>
                <p style={{ color: 'rgba(255,255,255,0.45)', fontSize: '13px' }}>আপনার অ্যাকাউন্টে প্রবেশ করুন</p>
              </div>

              {/* Email input */}
              <div>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: '8px', gap: '6px' }}>
                  <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#22D3EE', display: 'inline-block', boxShadow: '0 0 6px #22D3EE' }} />
                  <label style={{ color: 'rgba(255,255,255,0.65)', fontSize: '11px', letterSpacing: '1.5px', fontWeight: 600, textTransform: 'uppercase' }}>ইমেইল</label>
                </div>
                <div style={{ position: 'relative' }}>
                  <div style={{ position: 'absolute', top: '50%', left: '14px', transform: 'translateY(-50%)', pointerEvents: 'none' }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#22D3EE" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
                    </svg>
                  </div>
                  <input
                    type="email"
                    className="input-field"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    style={{
                      width: '100%', boxSizing: 'border-box',
                      background: 'rgba(255,255,255,0.055)',
                      border: '1px solid rgba(255,255,255,0.10)',
                      borderRadius: '14px',
                      padding: '13px 14px 13px 42px',
                      color: '#fff', fontSize: '15px',
                    }}
                  />
                </div>
              </div>

              {/* Password input */}
              <div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#F472B6', display: 'inline-block', boxShadow: '0 0 6px #F472B6' }} />
                    <label style={{ color: 'rgba(255,255,255,0.65)', fontSize: '11px', letterSpacing: '1.5px', fontWeight: 600, textTransform: 'uppercase' }}>পাসওয়ার্ড</label>
                  </div>
                  <button style={{ color: '#A78BFA', fontSize: '12px', fontWeight: 600, background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
                    পাসওয়ার্ড ভুলে গেছেন?
                  </button>
                </div>
                <div style={{ position: 'relative' }}>
                  <div style={{ position: 'absolute', top: '50%', left: '14px', transform: 'translateY(-50%)', pointerEvents: 'none' }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#F472B6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                    </svg>
                  </div>
                  <input
                    type={showPass ? 'text' : 'password'}
                    className="input-field"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="••••••••"
                    style={{
                      width: '100%', boxSizing: 'border-box',
                      background: 'rgba(255,255,255,0.055)',
                      border: '1px solid rgba(255,255,255,0.10)',
                      borderRadius: '14px',
                      padding: '13px 42px 13px 42px',
                      color: '#fff', fontSize: '15px',
                    }}
                  />
                  <button
                    onClick={() => setShowPass(!showPass)}
                    style={{ position: 'absolute', top: '50%', right: '14px', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.35)', padding: 0 }}>
                    {showPass
                      ? <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                      : <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    }
                  </button>
                </div>
              </div>

              {/* Login button */}
              <div style={{ position: 'relative', marginTop: '4px', overflow: 'hidden', borderRadius: '14px' }}>
                <button
                  className="btn-glow grad-pan"
                  style={{
                    width: '100%',
                    padding: '15px',
                    borderRadius: '14px',
                    border: 'none',
                    background: 'linear-gradient(90deg, #22D3EE, #A78BFA, #F472B6, #22D3EE)',
                    color: '#fff',
                    fontSize: '17px',
                    fontWeight: 700,
                    letterSpacing: '0.5px',
                    cursor: 'pointer',
                    position: 'relative',
                    overflow: 'hidden',
                  }}>
                  {/* shimmer overlay */}
                  <span style={{
                    position: 'absolute', top: 0, left: '-100%', width: '60%', height: '100%',
                    background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.22), transparent)',
                    animation: 'shimmer 2.4s ease-in-out infinite',
                  }} />
                  লগইন করুন →
                </button>
              </div>

              {/* Divider */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{ flex: 1, height: '1px', background: 'rgba(255,255,255,0.08)' }} />
                <span style={{ color: 'rgba(255,255,255,0.25)', fontSize: '11px' }}>অথবা</span>
                <div style={{ flex: 1, height: '1px', background: 'rgba(255,255,255,0.08)' }} />
              </div>

              {/* Register link */}
              <p style={{ textAlign: 'center', color: 'rgba(255,255,255,0.45)', fontSize: '14px' }}>
                অ্যাকাউন্ট নেই?{' '}
                <button style={{ color: '#22D3EE', fontWeight: 700, background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', padding: 0 }}>
                  রেজিস্টার করুন
                </button>
              </p>
            </div>
          </div>

          {/* Social proof */}
          <p style={{ textAlign: 'center', marginTop: '20px', color: 'rgba(255,255,255,0.25)', fontSize: '12px', letterSpacing: '0.3px' }}>
            🔒 ১,০০,০০০+ ব্যবহারকারীর বিশ্বাস
          </p>
        </div>

      </div>
    </div>
  );
}
