import React, { useState } from 'react';
import { ArrowRight, Zap, Phone, Lock } from 'lucide-react';

export default function NeonGreen() {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');

  return (
    <div className="min-h-[100dvh] w-full bg-[#0A0A0A] font-sans relative overflow-hidden flex flex-col items-center justify-center text-white">
      <style>{`
        @keyframes pulse-glow {
          0%, 100% {
            box-shadow: 0 0 15px 2px rgba(16, 185, 129, 0.4), inset 0 0 10px rgba(16, 185, 129, 0.2);
          }
          50% {
            box-shadow: 0 0 25px 5px rgba(16, 185, 129, 0.7), inset 0 0 20px rgba(16, 185, 129, 0.5);
          }
        }
        @keyframes slow-spin {
          from {
            transform: rotateZ(0deg);
          }
          to {
            transform: rotateZ(360deg);
          }
        }
        @keyframes fade-in-up {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        .neon-glow {
          animation: pulse-glow 2s ease-in-out infinite;
        }
        
        .rotating-hex {
          animation: slow-spin 6s linear infinite;
        }

        .dot-pattern {
          background-image: radial-gradient(rgba(16, 185, 129, 0.15) 1px, transparent 1px);
          background-size: 20px 20px;
        }

        .input-bottom-border {
          background: transparent;
          border: none;
          border-bottom: 2px solid rgba(16, 185, 129, 0.2);
          border-radius: 0;
          transition: all 0.3s ease;
        }
        
        .input-bottom-border:focus {
          outline: none;
          border-bottom-color: #10B981;
          box-shadow: 0 4px 10px -5px rgba(16, 185, 129, 0.5);
        }

        .fade-in {
          animation: fade-in-up 0.6s ease-out forwards;
        }
      `}</style>

      {/* Background Effects */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        {/* Radial Glow Top */}
        <div 
          className="absolute top-0 left-1/2 -translate-x-1/2 w-[150%] h-[600px] opacity-70"
          style={{ background: 'radial-gradient(circle, rgba(16,185,129,0.15) 0%, transparent 60%)' }}
        />
        
        {/* Circuit Board Dots */}
        <div className="absolute inset-0 dot-pattern opacity-50 mask-image-linear" style={{ WebkitMaskImage: 'linear-gradient(to bottom, transparent, black 10%, black 90%, transparent)' }} />
      </div>

      <div className="w-full max-w-[390px] px-6 z-10 flex flex-col min-h-screen py-12 justify-center">
        {/* Header / Logo Area */}
        <div className="flex flex-col items-center mb-12 fade-in" style={{ animationDelay: '0.1s' }}>
          <div className="relative w-24 h-24 flex items-center justify-center mb-6">
            {/* The rotating shape */}
            <div className="absolute inset-0 rotate-45 border border-[#10B981] bg-black/40 backdrop-blur-md rounded-2xl neon-glow rotating-hex"></div>
            
            {/* The stationary icon inside */}
            <Zap className="w-10 h-10 text-[#34D399] drop-shadow-[0_0_8px_rgba(52,211,153,0.8)] z-10" fill="#10B981" />
          </div>

          <h1 className="text-3xl font-black tracking-tight mb-2">
            EARN <span className="text-[#10B981] drop-shadow-[0_0_10px_rgba(16,185,129,0.4)]">SPACE</span>
          </h1>
          <p className="text-[#34D399]/70 text-xs tracking-[0.2em] font-medium uppercase">
            টাস্ক করুন • আয় করুন • বড় হন
          </p>
        </div>

        {/* Login Card */}
        <div className="w-full bg-[#0A0A0A]/80 backdrop-blur-xl p-8 rounded-3xl border fade-in shadow-2xl relative overflow-hidden" 
             style={{ 
               borderColor: 'rgba(16,185,129,0.2)', 
               backgroundColor: 'rgba(16, 185, 129, 0.02)',
               animationDelay: '0.2s' 
             }}>
          
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#10B981] to-transparent opacity-50"></div>

          <h2 className="text-xl font-bold mb-6 text-white">স্বাগতম ফিরে এসেছেন</h2>

          <div className="space-y-6">
            <div className="relative group">
              <Phone className="absolute left-0 top-3 w-5 h-5 text-[#6B7280] group-focus-within:text-[#10B981] transition-colors" />
              <input 
                type="tel" 
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="ফোন নম্বর" 
                className="w-full input-bottom-border bg-[#111111]/50 text-white pl-8 pr-4 py-3 text-sm placeholder:text-[#6B7280]"
              />
            </div>

            <div className="relative group">
              <Lock className="absolute left-0 top-3 w-5 h-5 text-[#6B7280] group-focus-within:text-[#10B981] transition-colors" />
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="পাসওয়ার্ড" 
                className="w-full input-bottom-border bg-[#111111]/50 text-white pl-8 pr-4 py-3 text-sm placeholder:text-[#6B7280]"
              />
              <button className="absolute right-0 top-3 text-xs text-[#10B981] font-medium hover:text-[#34D399]">
                ভুলে গেছেন?
              </button>
            </div>
          </div>

          <button className="w-full bg-[#10B981] hover:bg-[#34D399] text-black font-bold text-sm py-4 rounded-xl mt-8 flex items-center justify-center gap-2 transition-all active:scale-95 shadow-[0_4px_15px_-3px_rgba(16,185,129,0.4)]">
            লগইন করুন
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center text-sm text-[#6B7280] fade-in" style={{ animationDelay: '0.3s' }}>
          অ্যাকাউন্ট নেই? {' '}
          <button className="text-[#10B981] font-semibold hover:text-[#34D399] hover:underline underline-offset-4">
            নতুন অ্যাকাউন্ট খুলুন
          </button>
        </div>
      </div>
    </div>
  );
}
