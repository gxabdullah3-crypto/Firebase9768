import { Router } from "express";
import { desc, eq } from "drizzle-orm";
import {
  balanceTransactionsTable,
  db,
  usersTable,
} from "@workspace/db";
import {
  AdjustUserBalanceBody,
  AdjustUserBalanceParams,
  ListBalanceTransactionsQueryParams,
} from "@workspace/api-zod";
import { requireAdmin, requireAuth } from "../middlewares/requireAuth";
import { logger } from "../lib/logger";
import { centsToDecimal, decimalToCents } from "../lib/money";
import { WalletMutationError, applyWalletEntry } from "../lib/wallet-ledger";

const router = Router();

function isUniqueConstraintViolation(error: unknown): boolean {
  let current: unknown = error;
  while (current && typeof current === "object") {
    if ("code" in current && current.code === "23505") return true;
    current = "cause" in current ? current.cause : undefined;
  }
  return false;
}

function formatTransaction(transaction: typeof balanceTransactionsTable.$inferSelect) {
  return {
    id: transaction.id,
    userId: transaction.userId,
    wallet: transaction.wallet,
    transactionType: transaction.transactionType,
    amount: Number(transaction.amount),
    balanceAfter: Number(transaction.balanceAfter),
    description: transaction.description,
    idempotencyKey: transaction.idempotencyKey,
    referenceId: transaction.referenceId ?? null,
    actorId: transaction.actorId ?? null,
    createdAt: transaction.createdAt.toISOString(),
  };
}

router.get("/transactions", requireAuth, async (req, res) => {
  const parsed = ListBalanceTransactionsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid query" });
    return;
  }
  const currentUser = req.currentUser!;
  const requestedUserId = parsed.data.userId;
  if (currentUser.role !== "admin" && requestedUserId !== undefined && requestedUserId !== currentUser.id) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  try {
    const userId = currentUser.role === "admin" ? requestedUserId : currentUser.id;
    const transactions = await db.select().from(balanceTransactionsTable)
      .where(userId === undefined ? undefined : eq(balanceTransactionsTable.userId, userId))
      .orderBy(desc(balanceTransactionsTable.createdAt))
      .limit(100);
    res.json(transactions.map(formatTransaction));
  } catch (err) {
    logger.error({ err }, "List balance transactions error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/admin/users/:userId/balance-adjustments", requireAuth, requireAdmin, async (req, res) => {
  const params = AdjustUserBalanceParams.safeParse({ userId: Number(req.params.userId) });
  const body = AdjustUserBalanceBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid balance adjustment" });
    return;
  }

  let amount: string;
  let description: string;
  try {
    const absoluteCents = decimalToCents(body.data.amount);
    if (absoluteCents <= 0n) {
      res.status(400).json({ error: "Amount must be positive" });
      return;
    }
    amount = centsToDecimal(body.data.direction === "credit" ? absoluteCents : -absoluteCents);
    description = `অ্যাডমিন ব্যালেন্স সমন্বয়: ${body.data.reason.trim()}`;
  } catch {
    res.status(400).json({ error: "Amount must be a valid BDT amount" });
    return;
  }

  try {
    const [existing] = await db.select().from(balanceTransactionsTable)
      .where(eq(balanceTransactionsTable.idempotencyKey, body.data.idempotencyKey));
    if (existing) {
      const matches = existing.userId === params.data.userId
        && existing.actorId === req.currentUser!.id
        && existing.transactionType === "admin_adjustment"
        && existing.amount === amount
        && existing.description === description;
      if (!matches) {
        res.status(409).json({ error: "Idempotency key was already used" });
        return;
      }
      res.status(200).json(formatTransaction(existing));
      return;
    }

    const result = await db.transaction(async (tx) => {
      const [user] = await tx.select({ id: usersTable.id })
        .from(usersTable)
        .where(eq(usersTable.id, params.data.userId));
      if (!user) return { notFound: true as const };
      const entry = await applyWalletEntry(tx, {
        userId: params.data.userId,
        wallet: "main",
        transactionType: "admin_adjustment",
        amount,
        description,
        idempotencyKey: body.data.idempotencyKey,
        actorId: req.currentUser!.id,
      });
      return { transaction: entry.transaction };
    });

    if ("notFound" in result) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    res.status(201).json(formatTransaction(result.transaction));
  } catch (err) {
    if (isUniqueConstraintViolation(err)) {
      const [existing] = await db.select().from(balanceTransactionsTable)
        .where(eq(balanceTransactionsTable.idempotencyKey, body.data.idempotencyKey));
      const matches = existing
        && existing.userId === params.data.userId
        && existing.actorId === req.currentUser!.id
        && existing.transactionType === "admin_adjustment"
        && existing.amount === amount
        && existing.description === description;
      if (matches) {
        res.status(200).json(formatTransaction(existing));
        return;
      }
      if (existing) {
        res.status(409).json({ error: "Idempotency key was already used" });
        return;
      }
    }
    if (err instanceof WalletMutationError && err.code === "INSUFFICIENT_BALANCE") {
      res.status(400).json({ error: "Insufficient main balance" });
      return;
    }
    logger.error({ err }, "Adjust user balance error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;