import { Router } from "express";
import { and, desc, eq, inArray, isNotNull, or, sql } from "drizzle-orm";
import {
  db,
  investmentPlansTable,
  investmentsTable,
  notificationsTable,
} from "@workspace/db";
import {
  CancelInvestmentPlanParams,
  CancelInvestmentPlanResponse,
  CreateInvestmentBody,
  CreateInvestmentResponse,
  CreateInvestmentPlanBody,
  ListAdminInvestmentPlansResponse,
  ListInvestmentPlansResponse,
  ListInvestmentsResponse,
  UpdateInvestmentPlanStatusResponse,
  UpdateInvestmentPlanStatusBody,
  UpdateInvestmentPlanStatusParams,
} from "@workspace/api-zod";
import { requireAdmin, requireAuth } from "../middlewares/requireAuth";
import { logger } from "../lib/logger";
import { centsToDecimal, calculateSimpleProfitCents, decimalToCents } from "../lib/money";
import { WalletMutationError, applyWalletEntry } from "../lib/wallet-ledger";
import { settleMaturedInvestments } from "../lib/investment-maturity";

const router = Router();
const DAY_MS = 24 * 60 * 60 * 1000;

type PlanAggregate = {
  totalCollected: string;
  participantCount: number;
};

function effectivePlanAmounts(plan: typeof investmentPlansTable.$inferSelect) {
  const legacyAmountCents = decimalToCents(plan.amount);
  const targetCents = decimalToCents(plan.targetAmount) > 0n
    ? decimalToCents(plan.targetAmount)
    : legacyAmountCents;
  const minimumCents = decimalToCents(plan.minimumInvestment) > 0n
    ? decimalToCents(plan.minimumInvestment)
    : legacyAmountCents;
  return { targetCents, minimumCents };
}

function getPlanFundingStats(
  plan: typeof investmentPlansTable.$inferSelect,
  aggregate?: PlanAggregate,
) {
  const { targetCents, minimumCents } = effectivePlanAmounts(plan);
  const totalCollectedCents = decimalToCents(aggregate?.totalCollected ?? "0");
  const remainingCents = targetCents > totalCollectedCents
    ? targetCents - totalCollectedCents
    : 0n;
  const progressPercent = targetCents === 0n
    ? 0
    : Math.min(100, Number((totalCollectedCents * 10_000n) / targetCents) / 100);
  return {
    targetAmount: Number(centsToDecimal(targetCents)),
    minimumInvestment: Number(centsToDecimal(minimumCents)),
    fundingStatus: plan.fundingStatus,
    totalCollected: Number(centsToDecimal(totalCollectedCents)),
    remainingAmount: Number(centsToDecimal(remainingCents)),
    participantCount: aggregate?.participantCount ?? 0,
    progressPercent,
    activatedAt: plan.activatedAt?.toISOString() ?? null,
  };
}

async function loadPlanAggregates(planIds: number[]): Promise<Map<number, PlanAggregate>> {
  if (planIds.length === 0) return new Map();
  const rows = await db.select({
    planId: investmentsTable.planId,
    totalCollected: sql<string>`coalesce(sum(${investmentsTable.principal}), 0)::text`,
    participantCount: sql<number>`count(distinct ${investmentsTable.userId})::int`,
  }).from(investmentsTable)
    .where(and(
      inArray(investmentsTable.planId, planIds),
      or(
        eq(investmentsTable.status, "fundraising"),
        isNotNull(investmentsTable.activationAt),
        eq(investmentsTable.status, "refunded"),
      ),
    ))
    .groupBy(investmentsTable.planId);
  return new Map(rows.map((row) => [row.planId, {
    totalCollected: row.totalCollected,
    participantCount: row.participantCount,
  }]));
}

function formatPlan(
  plan: typeof investmentPlansTable.$inferSelect,
  aggregate?: PlanAggregate,
) {
  const stats = getPlanFundingStats(plan, aggregate);
  const principalCents = decimalToCents(stats.minimumInvestment);
  const profitCents = calculateSimpleProfitCents(
    principalCents,
    plan.ratePercent,
    plan.termDays,
    plan.ratePeriodDays,
  );
  const projectedReturnCents = principalCents + profitCents;
  const projectedReturnPercent = principalCents === 0n
    ? 0
    : Number((profitCents * 10_000n + principalCents / 2n) / principalCents) / 100;
  return {
    id: plan.id,
    title: plan.title,
    description: plan.description,
    amount: stats.minimumInvestment,
    ...stats,
    termDays: plan.termDays,
    ratePercent: Number(plan.ratePercent),
    ratePeriodDays: plan.ratePeriodDays,
    active: plan.active,
    projectedProfit: Number(centsToDecimal(profitCents)),
    projectedReturn: Number(centsToDecimal(projectedReturnCents)),
    projectedReturnPercent,
    createdAt: plan.createdAt.toISOString(),
  };
}

function formatInvestment(
  investment: typeof investmentsTable.$inferSelect,
  plan: typeof investmentPlansTable.$inferSelect,
  aggregate?: PlanAggregate,
) {
  const funding = getPlanFundingStats(plan, aggregate);
  return {
    id: investment.id,
    userId: investment.userId,
    planId: investment.planId,
    planTitle: investment.planTitle,
    principal: Number(investment.principal),
    estimatedProfit: Number(investment.estimatedProfit),
    totalReturn: Number(investment.totalReturn),
    termDays: investment.termDays,
    ratePercent: Number(investment.ratePercent),
    ratePeriodDays: investment.ratePeriodDays,
    status: investment.status,
    fundingStatus: funding.fundingStatus,
    targetAmount: funding.targetAmount,
    totalCollected: funding.totalCollected,
    remainingAmount: funding.remainingAmount,
    participantCount: funding.participantCount,
    progressPercent: funding.progressPercent,
    investedAt: investment.investedAt.toISOString(),
    activationAt: investment.activationAt?.toISOString() ?? null,
    maturityAt: investment.maturityAt?.toISOString() ?? null,
    settledAt: investment.settledAt?.toISOString() ?? null,
    refundedAt: investment.refundedAt?.toISOString() ?? null,
  };
}

function isUniqueConstraintViolation(error: unknown): boolean {
  let current: unknown = error;
  while (current && typeof current === "object") {
    if ("code" in current && current.code === "23505") return true;
    current = "cause" in current ? current.cause : undefined;
  }
  return false;
}

router.get("/investment-plans", requireAuth, async (_req, res) => {
  try {
    const plans = await db.select().from(investmentPlansTable)
      .where(eq(investmentPlansTable.active, true))
      .orderBy(desc(investmentPlansTable.createdAt));
    const aggregates = await loadPlanAggregates(plans.map((plan) => plan.id));
    res.set("Cache-Control", "no-store");
    res.json(ListInvestmentPlansResponse.parse(
      plans.filter((plan) => plan.fundingStatus !== "cancelled")
        .map((plan) => formatPlan(plan, aggregates.get(plan.id))),
    ));
  } catch (err) {
    logger.error({ err }, "List investment plans error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/admin/investment-plans", requireAuth, requireAdmin, async (_req, res) => {
  try {
    const plans = await db.select().from(investmentPlansTable)
      .orderBy(desc(investmentPlansTable.createdAt));
    const aggregates = await loadPlanAggregates(plans.map((plan) => plan.id));
    res.set("Cache-Control", "no-store");
    res.json(ListAdminInvestmentPlansResponse.parse(
      plans.map((plan) => formatPlan(plan, aggregates.get(plan.id))),
    ));
  } catch (err) {
    logger.error({ err }, "List admin investment plans error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/admin/investment-plans", requireAuth, requireAdmin, async (req, res) => {
  const parsed = CreateInvestmentPlanBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid investment plan" });
    return;
  }
  try {
    const input = parsed.data;
    const targetCents = decimalToCents(input.targetAmount);
    const minimumCents = decimalToCents(input.minimumInvestment);
    if (targetCents <= 0n || minimumCents <= 0n || minimumCents > targetCents) {
      res.status(400).json({ error: "Minimum contribution must be positive and no greater than the funding target" });
      return;
    }
    const [plan] = await db.insert(investmentPlansTable).values({
      title: input.title.trim(),
      description: input.description.trim(),
      amount: centsToDecimal(minimumCents),
      targetAmount: centsToDecimal(targetCents),
      minimumInvestment: centsToDecimal(minimumCents),
      termDays: input.termDays,
      ratePercent: Number(input.ratePercent).toFixed(2),
      ratePeriodDays: input.ratePeriodDays,
    }).returning();
    if (!plan) {
      res.status(500).json({ error: "Failed to create investment plan" });
      return;
    }
    res.status(201).json(ListInvestmentPlansResponse.element.parse(formatPlan(plan)));
  } catch (err) {
    logger.error({ err }, "Create investment plan error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/admin/investment-plans/:id/status", requireAuth, requireAdmin, async (req, res) => {
  const params = UpdateInvestmentPlanStatusParams.safeParse({ id: Number(req.params.id) });
  const body = UpdateInvestmentPlanStatusBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid plan status request" });
    return;
  }
  try {
    const [plan] = await db.update(investmentPlansTable)
      .set({ active: body.data.active })
      .where(and(
        eq(investmentPlansTable.id, params.data.id),
        eq(investmentPlansTable.fundingStatus, "fundraising"),
      ))
      .returning();
    if (!plan) {
      const [existing] = await db.select({ id: investmentPlansTable.id })
        .from(investmentPlansTable)
        .where(eq(investmentPlansTable.id, params.data.id));
      if (!existing) {
        res.status(404).json({ error: "Investment plan not found" });
        return;
      }
      res.status(400).json({ error: "Only a plan still raising funds can be paused or resumed" });
      return;
    }
    res.json(UpdateInvestmentPlanStatusResponse.parse(formatPlan(plan)));
  } catch (err) {
    logger.error({ err }, "Update investment plan status error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/admin/investment-plans/:id/cancel", requireAuth, requireAdmin, async (req, res) => {
  const params = CancelInvestmentPlanParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid plan cancellation request" });
    return;
  }

  try {
    const result = await db.transaction(async (tx) => {
      const [plan] = await tx.select().from(investmentPlansTable)
        .where(eq(investmentPlansTable.id, params.data.id))
        .for("update");
      if (!plan) return { notFound: true as const };
      if (plan.fundingStatus !== "fundraising") return { notOpen: true as const };

      const now = new Date();
      const [cancelledPlan] = await tx.update(investmentPlansTable)
        .set({ active: false, fundingStatus: "cancelled", cancelledAt: now })
        .where(eq(investmentPlansTable.id, plan.id))
        .returning();
      if (!cancelledPlan) throw new Error("Failed to cancel investment plan");

      const contributions = await tx.update(investmentsTable)
        .set({ status: "refunded", refundedAt: now })
        .where(and(
          eq(investmentsTable.planId, plan.id),
          eq(investmentsTable.status, "fundraising"),
        ))
        .returning();

      for (const contribution of contributions) {
        await applyWalletEntry(tx, {
          userId: contribution.userId,
          wallet: "main",
          transactionType: "investment_refund",
          amount: contribution.principal,
          description: `${plan.title} group plan cancelled: contribution refunded`,
          idempotencyKey: `investment:cancel:main:${contribution.id}`,
          referenceId: contribution.id,
          actorId: req.currentUser!.id,
        });
        await applyWalletEntry(tx, {
          userId: contribution.userId,
          wallet: "investment",
          transactionType: "investment_refund_unlock",
          amount: `-${contribution.principal}`,
          description: `${plan.title} group plan cancelled: locked contribution released`,
          idempotencyKey: `investment:cancel:locked:${contribution.id}`,
          referenceId: contribution.id,
          actorId: req.currentUser!.id,
        });
      }

      const participantIds = [...new Set(contributions.map((item) => item.userId))];
      if (participantIds.length > 0) {
        await tx.insert(notificationsTable).values(participantIds.map((userId) => ({
          userId,
          type: "success" as const,
          message: `${plan.title} group plan was cancelled. Your contribution has been returned to your main wallet.`,
        })));
      }
      return { plan: cancelledPlan };
    });

    if ("notFound" in result) {
      res.status(404).json({ error: "Investment plan not found" });
      return;
    }
    if ("notOpen" in result) {
      res.status(400).json({ error: "Only a plan still raising funds can be cancelled" });
      return;
    }
    const aggregates = await loadPlanAggregates([result.plan.id]);
    res.json(CancelInvestmentPlanResponse.parse(
      formatPlan(result.plan, aggregates.get(result.plan.id)),
    ));
  } catch (err) {
    logger.error({ err }, "Cancel investment plan error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/investments", requireAuth, async (req, res) => {
  try {
    const userId = req.currentUser!.id;
    await settleMaturedInvestments(userId);
    const investments = await db.select().from(investmentsTable)
      .where(eq(investmentsTable.userId, userId))
      .orderBy(desc(investmentsTable.investedAt));
    const planIds = [...new Set(investments.map((investment) => investment.planId))];
    const plans = planIds.length > 0
      ? await db.select().from(investmentPlansTable).where(inArray(investmentPlansTable.id, planIds))
      : [];
    const plansById = new Map(plans.map((plan) => [plan.id, plan]));
    const aggregates = await loadPlanAggregates(planIds);
    res.set("Cache-Control", "no-store");
    res.json(ListInvestmentsResponse.parse(investments.map((investment) => {
      const plan = plansById.get(investment.planId);
      if (!plan) throw new Error(`Investment plan ${investment.planId} is missing`);
      return formatInvestment(investment, plan, aggregates.get(plan.id));
    })));
  } catch (err) {
    logger.error({ err }, "List investments error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/investments", requireAuth, async (req, res) => {
  const parsed = CreateInvestmentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid investment request" });
    return;
  }
  const requestedAmountCents = decimalToCents(parsed.data.amount);
  try {
    const requestKey = parsed.data.idempotencyKey;
    const [existing] = await db.select().from(investmentsTable)
      .where(eq(investmentsTable.idempotencyKey, requestKey));
    if (existing) {
      if (
        existing.userId !== req.currentUser!.id
        || existing.planId !== parsed.data.planId
        || decimalToCents(existing.principal) !== requestedAmountCents
      ) {
        res.status(409).json({ error: "Idempotency key was already used" });
        return;
      }
      const [plan] = await db.select().from(investmentPlansTable)
        .where(eq(investmentPlansTable.id, existing.planId));
      if (!plan) throw new Error(`Investment plan ${existing.planId} is missing`);
      const aggregates = await loadPlanAggregates([plan.id]);
      res.status(200).json(CreateInvestmentResponse.parse(
        formatInvestment(existing, plan, aggregates.get(plan.id)),
      ));
      return;
    }

    const result = await db.transaction(async (tx) => {
      const [plan] = await tx.select().from(investmentPlansTable)
        .where(and(
          eq(investmentPlansTable.id, parsed.data.planId),
          eq(investmentPlansTable.active, true),
          eq(investmentPlansTable.fundingStatus, "fundraising"),
        ))
        .for("update");
      if (!plan) return { unavailable: true as const };

      const { targetCents, minimumCents } = effectivePlanAmounts(plan);
      const principalCents = requestedAmountCents;
      if (principalCents < minimumCents) {
        return { belowMinimum: true as const, minimumCents };
      }
      const profitCents = calculateSimpleProfitCents(
        principalCents,
        plan.ratePercent,
        plan.termDays,
        plan.ratePeriodDays,
      );
      const now = new Date();
      const [investment] = await tx.insert(investmentsTable).values({
        userId: req.currentUser!.id,
        planId: plan.id,
        planTitle: plan.title,
        principal: centsToDecimal(principalCents),
        estimatedProfit: centsToDecimal(profitCents),
        totalReturn: centsToDecimal(principalCents + profitCents),
        termDays: plan.termDays,
        ratePercent: plan.ratePercent,
        ratePeriodDays: plan.ratePeriodDays,
        idempotencyKey: requestKey,
        investedAt: now,
        status: "fundraising",
        maturityAt: null,
      }).returning();
      if (!investment) throw new Error("Failed to create investment position");

      await applyWalletEntry(tx, {
        userId: req.currentUser!.id,
        wallet: "main",
        transactionType: "investment_open",
        amount: centsToDecimal(-principalCents),
        description: `${plan.title} ইনভেস্টমেন্টে টাকা স্থানান্তর`,
        idempotencyKey: `investment:open:main:${investment.id}`,
        referenceId: investment.id,
      });
      await applyWalletEntry(tx, {
        userId: req.currentUser!.id,
        wallet: "investment",
        transactionType: "investment_lock",
        amount: centsToDecimal(principalCents),
        description: `${plan.title} মেয়াদ পর্যন্ত লক করা হয়েছে`,
        idempotencyKey: `investment:open:locked:${investment.id}`,
        referenceId: investment.id,
      });

      const [fundingTotal] = await tx.select({
        amount: sql<string>`coalesce(sum(${investmentsTable.principal}), 0)::text`,
      }).from(investmentsTable)
        .where(and(
          eq(investmentsTable.planId, plan.id),
          eq(investmentsTable.status, "fundraising"),
        ));
      const totalCents = decimalToCents(fundingTotal?.amount ?? "0");
      let activated = false;
      if (totalCents >= targetCents) {
        const activatedAt = new Date();
        const maturityAt = new Date(activatedAt.getTime() + plan.termDays * DAY_MS);
        const [updatedPlan] = await tx.update(investmentPlansTable)
          .set({ fundingStatus: "active", activatedAt })
          .where(and(
            eq(investmentPlansTable.id, plan.id),
            eq(investmentPlansTable.fundingStatus, "fundraising"),
          ))
          .returning();
        if (updatedPlan) {
          const activatedContributions = await tx.update(investmentsTable)
            .set({ status: "active", activationAt: activatedAt, maturityAt })
            .where(and(
              eq(investmentsTable.planId, plan.id),
              eq(investmentsTable.status, "fundraising"),
            ))
            .returning({ userId: investmentsTable.userId });
          const participantIds = [...new Set(activatedContributions.map((item) => item.userId))];
          if (participantIds.length > 0) {
            await tx.insert(notificationsTable).values(participantIds.map((userId) => ({
              userId,
              type: "success" as const,
              message: `${plan.title} reached its funding target. Your ${plan.termDays}-day term has started.`,
            })));
          }
          activated = true;
        }
      }
      const [currentInvestment] = await tx.select().from(investmentsTable)
        .where(eq(investmentsTable.id, investment.id));
      if (!currentInvestment) throw new Error("Failed to reload investment position");
      return { investment: currentInvestment, planId: plan.id, activated };
    });

    if ("unavailable" in result) {
      res.status(400).json({ error: "This plan is no longer raising funds" });
      return;
    }
    if ("belowMinimum" in result && typeof result.minimumCents === "bigint") {
      res.status(400).json({
        error: `Contribution must be at least ${centsToDecimal(result.minimumCents)}`,
      });
      return;
    }
    const [plan] = await db.select().from(investmentPlansTable)
      .where(eq(investmentPlansTable.id, result.planId));
    if (!plan) throw new Error(`Investment plan ${result.planId} is missing`);
    const aggregates = await loadPlanAggregates([plan.id]);
    res.status(201).json(CreateInvestmentResponse.parse(
      formatInvestment(result.investment, plan, aggregates.get(plan.id)),
    ));
  } catch (err) {
    if (isUniqueConstraintViolation(err)) {
      const [existing] = await db.select().from(investmentsTable)
        .where(eq(investmentsTable.idempotencyKey, parsed.data.idempotencyKey));
      if (
        existing?.userId === req.currentUser!.id
        && existing.planId === parsed.data.planId
        && decimalToCents(existing.principal) === requestedAmountCents
      ) {
        const [plan] = await db.select().from(investmentPlansTable)
          .where(eq(investmentPlansTable.id, existing.planId));
        if (!plan) throw new Error(`Investment plan ${existing.planId} is missing`);
        const aggregates = await loadPlanAggregates([plan.id]);
        res.status(200).json(CreateInvestmentResponse.parse(
          formatInvestment(existing, plan, aggregates.get(plan.id)),
        ));
        return;
      }
      if (existing) {
        res.status(409).json({ error: "Idempotency key was already used" });
        return;
      }
    }
    if (err instanceof WalletMutationError && err.code === "INSUFFICIENT_BALANCE") {
      res.status(400).json({ error: "Insufficient main balance for this investment" });
      return;
    }
    logger.error({ err }, "Create investment error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;