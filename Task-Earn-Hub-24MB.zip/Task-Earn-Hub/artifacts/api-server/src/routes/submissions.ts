import { Router } from "express";
import { db, submissionsTable, tasksTable, usersTable, appSettingsTable, notificationsTable, assistantActivityTable } from "@workspace/db";
import { eq, and, desc, count } from "drizzle-orm";
import {
  CreateSubmissionBody,
  GetSubmissionParams,
  ApproveSubmissionParams,
  RejectSubmissionParams,
  RejectSubmissionBody,
} from "@workspace/api-zod";
import { requireAuth, requireAdminOrAssistant } from "../middlewares/requireAuth";
import { logger } from "../lib/logger";
import { sendPushToUser, sendPushToAdmins } from "./push";
import { centsToDecimal, decimalToCents } from "../lib/money";
import { applyWalletEntry } from "../lib/wallet-ledger";

const router = Router();

function formatUser(u: typeof usersTable.$inferSelect) {
  return { id: u.id, name: u.name, email: u.email, phone: u.phone ?? null, role: u.role, status: u.status, balance: Number(u.balance), investmentBalance: Number(u.investmentBalance), referralCode: u.referralCode, createdAt: u.createdAt.toISOString() };
}
function formatTask(t: typeof tasksTable.$inferSelect) {
  return { id: t.id, title: t.title, description: t.description, reward: Number(t.reward), link: t.link ?? null, status: t.status, createdBy: t.createdBy ?? null, createdAt: t.createdAt.toISOString() };
}
function formatSubmission(s: typeof submissionsTable.$inferSelect, task?: typeof tasksTable.$inferSelect, user?: typeof usersTable.$inferSelect) {
  return {
    id: s.id, taskId: s.taskId, userId: s.userId, screenshotUrl: s.screenshotUrl,
    description: s.description, status: s.status, rejectionReason: s.rejectionReason ?? null,
    createdAt: s.createdAt.toISOString(),
    task: task ? formatTask(task) : undefined,
    user: user ? formatUser(user) : undefined,
  };
}

function canAccessSubmission(
  user: NonNullable<Express.Request["currentUser"]>,
  task: typeof tasksTable.$inferSelect | undefined,
  submission: typeof submissionsTable.$inferSelect,
) {
  if (user.role === "admin") return true;
  if (user.role === "assistant") return task?.createdBy === user.id;
  return submission.userId === user.id;
}

async function createNotification(userId: number, message: string, type: "success" | "error" | "info") {
  try {
    await db.insert(notificationsTable).values({ userId, message, type });
  } catch (err) {
    logger.error({ err }, "Failed to create notification");
  }
}

router.get("/submissions", requireAuth, async (req, res) => {
  try {
    res.set("Cache-Control", "no-store");
    const { status, taskId, userId } = req.query as { status?: string; taskId?: string; userId?: string };
    const user = req.currentUser!;

    const ownershipFilter = user.role === "admin"
      ? undefined
      : user.role === "assistant"
      ? eq(tasksTable.createdBy, user.id)
      : eq(submissionsTable.userId, user.id);

    const rows = await db.select().from(submissionsTable)
      .leftJoin(tasksTable, eq(submissionsTable.taskId, tasksTable.id))
      .leftJoin(usersTable, eq(submissionsTable.userId, usersTable.id))
      .where(ownershipFilter)
      .orderBy(desc(submissionsTable.createdAt));

    const filtered = rows.filter((r) => {
      if (!canAccessSubmission(user, r.tasks ?? undefined, r.submissions)) return false;
      if (status && r.submissions.status !== status) return false;
      if (taskId && r.submissions.taskId !== Number(taskId)) return false;
      if (userId && r.submissions.userId !== Number(userId)) return false;
      return true;
    });

    return res.json(filtered.map((r) => formatSubmission(r.submissions, r.tasks ?? undefined, r.users ?? undefined)));
  } catch (err) {
    logger.error({ err }, "List submissions error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/submissions", requireAuth, async (req, res) => {
  const parsed = CreateSubmissionBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input" });

  try {
    const user = req.currentUser!;
    const [task] = await db.select().from(tasksTable).where(eq(tasksTable.id, parsed.data.taskId));
    if (!task) return res.status(404).json({ error: "Task not found" });
    if (task.status !== "active") return res.status(400).json({ error: "Task is not active" });
    if (task.createdBy === user.id) {
      return res.status(403).json({ error: "You cannot submit your own task" });
    }

    const existing = await db.select().from(submissionsTable).where(
      and(eq(submissionsTable.taskId, parsed.data.taskId), eq(submissionsTable.userId, user.id))
    );
    if (existing.length > 0) return res.status(400).json({ error: "You already submitted this task" });

    const [submission] = await db.insert(submissionsTable).values({
      taskId: parsed.data.taskId,
      userId: user.id,
      screenshotUrl: parsed.data.screenshotUrl,
      description: parsed.data.description,
    }).returning();

    if (!submission) return res.status(500).json({ error: "Failed to create submission" });

    // Notify admins of new submission
    sendPushToAdmins(
      "নতুন সাবমিশন",
      `${user.name} — "${task.title}" টাস্কে সাবমিশন করেছেন। রিভিউ করুন।`,
      "/admin/submissions"
    ).catch(() => {});

    return res.status(201).json(formatSubmission(submission, task, user));
  } catch (err) {
    logger.error({ err }, "Create submission error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/submissions/:id", requireAuth, async (req, res) => {
  const parsed = GetSubmissionParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) return res.status(400).json({ error: "Invalid id" });
  try {
    res.set("Cache-Control", "no-store");
    const rows = await db.select().from(submissionsTable)
      .leftJoin(tasksTable, eq(submissionsTable.taskId, tasksTable.id))
      .leftJoin(usersTable, eq(submissionsTable.userId, usersTable.id))
      .where(eq(submissionsTable.id, parsed.data.id));

    if (!rows[0]) return res.status(404).json({ error: "Submission not found" });
    const r = rows[0];
    if (!canAccessSubmission(req.currentUser!, r.tasks ?? undefined, r.submissions)) {
      return res.status(403).json({ error: "Forbidden" });
    }
    return res.json(formatSubmission(r.submissions, r.tasks ?? undefined, r.users ?? undefined));
  } catch (err) {
    logger.error({ err }, "Get submission error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/submissions/:id/approve", requireAuth, requireAdminOrAssistant, async (req, res) => {
  const parsed = ApproveSubmissionParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) return res.status(400).json({ error: "Invalid id" });

  try {
    const [submission] = await db.select().from(submissionsTable).where(eq(submissionsTable.id, parsed.data.id));
    if (!submission) return res.status(404).json({ error: "Submission not found" });
    if (req.currentUser!.role === "assistant" && submission.userId === req.currentUser!.id) {
      return res.status(403).json({ error: "You cannot review your own submission" });
    }
    const [task] = await db.select().from(tasksTable).where(eq(tasksTable.id, submission.taskId));
    if (!task) return res.status(404).json({ error: "Task not found" });
    if (req.currentUser!.role === "assistant" && task.createdBy !== req.currentUser!.id) {
      return res.status(403).json({ error: "You can only review submissions for your own tasks" });
    }

    const result = await db.transaction(async (tx) => {
      const [changed] = await tx.update(submissionsTable)
        .set({ status: "approved" })
        .where(and(
          eq(submissionsTable.id, parsed.data.id),
          eq(submissionsTable.status, "pending"),
        ))
        .returning();
      if (!changed) return undefined;

      const [worker] = await tx.select().from(usersTable).where(eq(usersTable.id, changed.userId));
      if (!worker) throw new Error("Submission worker not found");

      if (req.currentUser!.role === "assistant") {
        await tx.insert(assistantActivityTable).values({
          assistantId: req.currentUser!.id,
          action: "submission_approved",
          taskId: task.id,
          submissionId: changed.id,
          details: task.title,
        });
      }

      const rewardCents = decimalToCents(task.reward);
      await applyWalletEntry(tx, {
        userId: worker.id,
        wallet: "main",
        transactionType: "task_reward",
        amount: centsToDecimal(rewardCents),
        description: `টাস্ক রিওয়ার্ড: ${task.title}`,
        idempotencyKey: `submission:${changed.id}:task_reward`,
        referenceId: changed.id,
      });

      const messages: Array<{ userId: number; title: string; message: string; url: string; type: "success" | "info" }> = [];
      messages.push({
        userId: worker.id,
        title: "সাবমিশন অনুমোদিত",
        message: `আপনার "${task.title}" সাবমিশন অনুমোদিত! ৳${centsToDecimal(rewardCents)} BDT ব্যালেন্সে যোগ হয়েছে।`,
        url: "/submissions",
        type: "success",
      });

      const [approvedCount] = await tx.select({ count: count() })
        .from(submissionsTable)
        .where(and(
          eq(submissionsTable.userId, worker.id),
          eq(submissionsTable.status, "approved"),
        ));
      if (Number(approvedCount?.count ?? 0) === 1 && worker.status === "no_active") {
        await tx.update(usersTable).set({ status: "active" }).where(eq(usersTable.id, worker.id));
        messages.push({
          userId: worker.id,
          title: "অ্যাকাউন্ট সক্রিয়",
          message: "আপনার প্রথম টাস্ক অনুমোদিত হয়েছে — অ্যাকাউন্ট এখন সক্রিয়।",
          url: "/dashboard",
          type: "success",
        });
      }

      const [settings] = await tx.select().from(appSettingsTable).limit(1);
      const addCommission = async (recipientId: number, amountCents: bigint, type: string, description: string, message: string, title: string) => {
        if (amountCents <= 0n) return;
        await applyWalletEntry(tx, {
          userId: recipientId,
          wallet: "main",
          transactionType: type,
          amount: centsToDecimal(amountCents),
          description,
          idempotencyKey: `submission:${changed.id}:${type}`,
          referenceId: changed.id,
        });
        messages.push({ userId: recipientId, title, message, url: "/dashboard", type: "success" });
      };
      const commissionCents = (rate: string | number) => {
        const rateHundredths = decimalToCents(rate);
        return (rewardCents * rateHundredths + 5_000n) / 10_000n;
      };

      if (worker.referredBy) {
        const [referrer] = await tx.select().from(usersTable)
          .where(eq(usersTable.referralCode, worker.referredBy));
        if (referrer) {
          const directRate = settings?.referralCommissionPercent ?? "5";
          const directCents = commissionCents(directRate);
          await addCommission(
            referrer.id,
            directCents,
            "referral_commission",
            `রেফারেল কমিশন: ${worker.name} — ${task.title}`,
            `রেফারেল কমিশন পেয়েছেন! "${task.title}" টাস্কে ${worker.name} এর জন্য ৳${centsToDecimal(directCents)} BDT যোগ হয়েছে।`,
            "রেফারেল কমিশন",
          );

          if (referrer.referredBy) {
            const [level2Referrer] = await tx.select().from(usersTable)
              .where(eq(usersTable.referralCode, referrer.referredBy));
            if (level2Referrer) {
              const level2Rate = settings?.level2CommissionPercent ?? "5";
              const level2Cents = commissionCents(level2Rate);
              await addCommission(
                level2Referrer.id,
                level2Cents,
                "referral_l2_commission",
                `লেভেল-২ রেফারেল কমিশন: ${worker.name} — ${task.title}`,
                `লেভেল-২ রেফারেল কমিশন! "${task.title}" টাস্কে ৳${centsToDecimal(level2Cents)} BDT ব্যালেন্সে যোগ হয়েছে।`,
                "লেভেল-২ রেফারেল কমিশন",
              );
            }
          }

          if (Number(approvedCount?.count ?? 0) === 1) {
            const bonusCents = decimalToCents(settings?.referralFirstTaskBonus ?? "10");
            await addCommission(
              referrer.id,
              bonusCents,
              "referral_first_task_bonus",
              `প্রথম টাস্ক রেফারেল বোনাস: ${worker.name}`,
              `${worker.name} প্রথম টাস্ক সম্পন্ন করেছেন! ৳${centsToDecimal(bonusCents)} BDT রেফারেল বোনাস যোগ হয়েছে।`,
              "প্রথম টাস্ক রেফারেল বোনাস",
            );
          }
        }
      }
      return { submission: changed, messages };
    });

    if (!result) return res.status(409).json({ error: "Submission has already been reviewed" });
    for (const item of result.messages) {
      createNotification(item.userId, item.message, item.type).catch(() => {});
      sendPushToUser(item.userId, item.title, item.message, item.url).catch(() => {});
    }
    const [finalUser] = await db.select().from(usersTable).where(eq(usersTable.id, result.submission.userId));
    return res.json(formatSubmission(result.submission, task, finalUser ?? undefined));
  } catch (err) {
    logger.error({ err }, "Approve submission error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/submissions/:id/reject", requireAuth, requireAdminOrAssistant, async (req, res) => {
  const paramsParsed = RejectSubmissionParams.safeParse({ id: Number(req.params.id) });
  const bodyParsed = RejectSubmissionBody.safeParse(req.body);
  if (!paramsParsed.success || !bodyParsed.success) return res.status(400).json({ error: "Invalid input" });

  try {
    const [submission] = await db.select().from(submissionsTable).where(eq(submissionsTable.id, paramsParsed.data.id));
    if (!submission) return res.status(404).json({ error: "Submission not found" });
    if (submission.status !== "pending") return res.status(400).json({ error: "Submission is not pending" });

    const [task] = await db.select().from(tasksTable).where(eq(tasksTable.id, submission.taskId));
    if (!task) return res.status(404).json({ error: "Task not found" });
    if (req.currentUser!.role === "assistant" && task.createdBy !== req.currentUser!.id) {
      return res.status(403).json({ error: "You can only review submissions for your own tasks" });
    }
    if (req.currentUser!.role === "assistant" && submission.userId === req.currentUser!.id) {
      return res.status(403).json({ error: "You cannot review your own submission" });
    }

    const updated = await db.transaction(async (tx) => {
      const [changed] = await tx.update(submissionsTable)
        .set({ status: "rejected", rejectionReason: bodyParsed.data.reason })
        .where(and(
          eq(submissionsTable.id, paramsParsed.data.id),
          eq(submissionsTable.status, "pending"),
        ))
        .returning();
      if (!changed) return undefined;
      if (req.currentUser!.role === "assistant") {
        await tx.insert(assistantActivityTable).values({
          assistantId: req.currentUser!.id,
          action: "submission_rejected",
          taskId: task.id,
          submissionId: submission.id,
          details: task.title,
        });
      }
      return changed;
    });
    if (!updated) return res.status(409).json({ error: "Submission has already been reviewed" });

    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, submission.userId));

    const msg = `আপনার "${task?.title ?? "টাস্ক"}" সাবমিশন প্রত্যাখ্যাত। কারণ: ${bodyParsed.data.reason}`;
    createNotification(submission.userId, msg, "error").catch(() => {});
    sendPushToUser(submission.userId, "সাবমিশন প্রত্যাখ্যাত ❌", msg, "/submissions").catch(() => {});

    return res.json(formatSubmission(updated!, task, user));
  } catch (err) {
    logger.error({ err }, "Reject submission error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
