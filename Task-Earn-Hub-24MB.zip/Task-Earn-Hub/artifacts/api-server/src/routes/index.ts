import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import tasksRouter from "./tasks";
import submissionsRouter from "./submissions";
import withdrawalsRouter from "./withdrawals";
import adminRouter from "./admin";
import settingsRouter from "./settings";
import referralsRouter from "./referrals";
import uploadRouter from "./upload";
import notificationsRouter from "./notifications";
import pushRouter from "./push";
import investmentsRouter from "./investments";
import transactionsRouter from "./transactions";

const router: IRouter = Router();

router.use(healthRouter);
router.use(uploadRouter);
router.use(authRouter);
router.use(tasksRouter);
router.use(submissionsRouter);
router.use(withdrawalsRouter);
router.use(adminRouter);
router.use(settingsRouter);
router.use(referralsRouter);
router.use(notificationsRouter);
router.use(pushRouter);
router.use(investmentsRouter);
router.use(transactionsRouter);

export default router;
