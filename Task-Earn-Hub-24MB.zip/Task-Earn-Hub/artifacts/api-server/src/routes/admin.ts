import { Router } from "express";
import { db, usersTable, tasksTable, submissionsTable, withdrawalsTable, assistantActivityTable } from "@workspace/db";
import { eq, sum, count, and, inArray, gte, desc } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../middlewares/requireAuth";
import { logger } from "../lib/logger";

const router = Router();

function startOfBangladeshDay(now = new Date()) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Dhaka",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(now);
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return new Date(`${values.year}-${values.month}-${values.day}T00:00:00+06:00`);
}

router.get("/admin/stats", requireAuth, requireAdmin, async (req, res) => {
  try {
    const [totalUsersResult] = await db.select({ count: count() }).from(usersTable);
    const [totalTasksResult] = await db.select({ count: count() }).from(tasksTable);
    const [pendingSubsResult] = await db.select({ count: count() }).from(submissionsTable)
      .where(eq(submissionsTable.status, "pending"));
    const [pendingWdResult] = await db.select({ count: count() }).from(withdrawalsTable)
      .where(eq(withdrawalsTable.status, "pending"));
    const [totalPaidResult] = await db.select({ total: sum(withdrawalsTable.amount) }).from(withdrawalsTable)
      .where(eq(withdrawalsTable.status, "approved"));
    const [totalBalanceResult] = await db.select({ total: sum(usersTable.balance) }).from(usersTable);

    return res.json({
      totalUsers: Number(totalUsersResult?.count ?? 0),
      totalTasks: Number(totalTasksResult?.count ?? 0),
      pendingSubmissions: Number(pendingSubsResult?.count ?? 0),
      pendingWithdrawals: Number(pendingWdResult?.count ?? 0),
      totalPaid: Number(totalPaidResult?.total ?? 0),
      totalBalance: Number(totalBalanceResult?.total ?? 0),
    });
  } catch (err) {
    logger.error({ err }, "Admin stats error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/admin/users", requireAuth, requireAdmin, async (req, res) => {
  try {
    const users = await db.select().from(usersTable).orderBy(usersTable.createdAt);
    return res.json(users.map((u) => ({
      id: u.id,
      name: u.name,
      email: u.email,
      phone: u.phone ?? null,
      role: u.role,
      status: u.status,
      balance: Number(u.balance),
      investmentBalance: Number(u.investmentBalance),
      referralCode: u.referralCode,
      createdAt: u.createdAt.toISOString(),
    })));
  } catch (err) {
    logger.error({ err }, "List users error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/admin/assistants", requireAuth, requireAdmin, async (_req, res) => {
  try {
    const assistants = await db.select().from(usersTable)
      .where(eq(usersTable.role, "assistant"))
      .orderBy(usersTable.createdAt);

    const startOfToday = startOfBangladeshDay();
    const [todayCompleted] = await db.select({ count: count() })
      .from(assistantActivityTable)
      .where(and(
        eq(assistantActivityTable.action, "submission_approved"),
        gte(assistantActivityTable.createdAt, startOfToday),
      ));

    const assistantStats = await Promise.all(assistants.map(async (assistant) => {
      const assistantTasks = await db.select({ id: tasksTable.id })
        .from(tasksTable)
        .where(eq(tasksTable.createdBy, assistant.id));
      const taskIds = assistantTasks.map((task) => task.id);

      let approvedCount = 0;
      let rejectedCount = 0;
      if (taskIds.length > 0) {
        const [approved] = await db.select({ count: count() })
          .from(submissionsTable)
          .where(and(inArray(submissionsTable.taskId, taskIds), eq(submissionsTable.status, "approved")));
        const [rejected] = await db.select({ count: count() })
          .from(submissionsTable)
          .where(and(inArray(submissionsTable.taskId, taskIds), eq(submissionsTable.status, "rejected")));
        approvedCount = Number(approved?.count ?? 0);
        rejectedCount = Number(rejected?.count ?? 0);
      }

      return {
        id: assistant.id,
        name: assistant.name,
        email: assistant.email,
        status: assistant.status,
        assignedAt: (assistant.assistantAssignedAt ?? assistant.createdAt).toISOString(),
        taskCount: taskIds.length,
        approvedCount,
        rejectedCount,
      };
    }));

    return res.json({
      todayCompletedTasks: Number(todayCompleted?.count ?? 0),
      assistants: assistantStats,
    });
  } catch (err) {
    logger.error({ err }, "List assistants error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/admin/assistants/:userId", requireAuth, requireAdmin, async (req, res) => {
  const userId = Number(req.params.userId);
  if (!Number.isInteger(userId) || userId <= 0) return res.status(400).json({ error: "Invalid user id" });

  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    if (!user) return res.status(404).json({ error: "User not found" });
    if (user.role === "admin") return res.status(400).json({ error: "An admin cannot be assigned as assistant" });
    if (user.role === "assistant") return res.status(400).json({ error: "User is already an assistant" });

    const [updated] = await db.update(usersTable)
      .set({ role: "assistant", assistantAssignedAt: new Date() })
      .where(eq(usersTable.id, userId))
      .returning();
    if (!updated) return res.status(500).json({ error: "Failed to assign assistant" });

    return res.json({
      id: updated.id,
      name: updated.name,
      email: updated.email,
      status: updated.status,
      assignedAt: (updated.assistantAssignedAt ?? updated.createdAt).toISOString(),
      taskCount: 0,
      approvedCount: 0,
      rejectedCount: 0,
    });
  } catch (err) {
    logger.error({ err }, "Assign assistant error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/admin/assistants/:userId", requireAuth, requireAdmin, async (req, res) => {
  const userId = Number(req.params.userId);
  if (!Number.isInteger(userId) || userId <= 0) return res.status(400).json({ error: "Invalid user id" });

  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    if (!user) return res.status(404).json({ error: "User not found" });
    if (user.role !== "assistant") return res.status(400).json({ error: "User is not an assistant" });

    await db.update(usersTable)
      .set({ role: "user", assistantAssignedAt: null })
      .where(eq(usersTable.id, userId));
    return res.json({ ok: true });
  } catch (err) {
    logger.error({ err }, "Remove assistant error");
    return res.status(500).json({ error: "Failed to remove assistant" });
  }
});

router.get("/admin/assistants/:userId/activity", requireAuth, requireAdmin, async (req, res) => {
  const userId = Number(req.params.userId);
  if (!Number.isInteger(userId) || userId <= 0) return res.status(400).json({ error: "Invalid user id" });

  try {
    const [assistant] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    if (!assistant) return res.status(404).json({ error: "Assistant not found" });

    const activity = await db.select().from(assistantActivityTable)
      .where(eq(assistantActivityTable.assistantId, userId))
      .orderBy(desc(assistantActivityTable.createdAt))
      .limit(100);

    return res.json(activity.map((item) => ({
      id: item.id,
      assistantId: item.assistantId,
      action: item.action,
      taskId: item.taskId ?? null,
      submissionId: item.submissionId ?? null,
      details: item.details ?? null,
      createdAt: item.createdAt.toISOString(),
    })));
  } catch (err) {
    logger.error({ err }, "Get assistant activity error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
