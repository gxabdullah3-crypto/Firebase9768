import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq, inArray } from "drizzle-orm";
import { requireAuth } from "../middlewares/requireAuth";
import { logger } from "../lib/logger";

const router = Router();

router.get("/referrals", requireAuth, async (req, res) => {
  try {
    const user = req.currentUser!;

    // Level 1: directly referred by me
    const level1 = await db.select().from(usersTable)
      .where(eq(usersTable.referredBy, user.referralCode));

    // Level 2: referred by any of my level-1 members
    let level2: typeof usersTable.$inferSelect[] = [];
    if (level1.length > 0) {
      const level1Codes = level1.map((u) => u.referralCode);
      level2 = await db.select().from(usersTable)
        .where(inArray(usersTable.referredBy, level1Codes));
    }

    const formatMember = (u: typeof usersTable.$inferSelect, referredByName?: string) => ({
      id: u.id,
      name: u.name,
      email: u.email,
      createdAt: u.createdAt.toISOString(),
      referralCode: u.referralCode,
      status: u.status,
      referredByName: referredByName ?? null,
    });

    // Build a map from referralCode -> name for level1 members
    const level1ByCode = new Map(level1.map((u) => [u.referralCode, u.name]));

    return res.json({
      direct: level1.map((u) => formatMember(u)),
      indirect: level2.map((u) => formatMember(u, level1ByCode.get(u.referredBy ?? "") ?? undefined)),
    });
  } catch (err) {
    logger.error({ err }, "List referrals error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
