import { Router } from "express";
import { db, appSettingsTable } from "@workspace/db";
import { UpdateSettingsBody } from "@workspace/api-zod";
import { requireAuth, requireAdmin } from "../middlewares/requireAuth";
import { logger } from "../lib/logger";

const router = Router();

function formatSettings(s: typeof appSettingsTable.$inferSelect) {
  return {
    id: s.id,
    referralCommissionPercent: Number(s.referralCommissionPercent),
    minWithdrawal: Number(s.minWithdrawal),
    appName: s.appName,
    primaryColor: s.primaryColor,
    logoText: s.logoText,
    appDownloadUrl: s.appDownloadUrl ?? null,
    telegramUrl: s.telegramUrl ?? null,
    whatsappUrl: s.whatsappUrl ?? null,
    referralFirstTaskBonus: s.referralFirstTaskBonus != null ? Number(s.referralFirstTaskBonus) : 10,
    level2CommissionPercent: s.level2CommissionPercent != null ? Number(s.level2CommissionPercent) : 5,
  };
}

router.get("/settings", async (req, res) => {
  try {
    const rows = await db.select().from(appSettingsTable);
    if (!rows[0]) {
      const [created] = await db.insert(appSettingsTable).values({
        referralCommissionPercent: "5",
        minWithdrawal: "50",
        appName: "Earn Space",
        primaryColor: "#e11d48",
        logoText: "E",
      }).returning();
      return res.json(formatSettings(created!));
    }
    return res.json(formatSettings(rows[0]));
  } catch (err) {
    logger.error({ err }, "Get settings error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/settings", requireAuth, requireAdmin, async (req, res) => {
  const parsed = UpdateSettingsBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input" });

  try {
    const rows = await db.select().from(appSettingsTable);
    const updates: Partial<typeof appSettingsTable.$inferInsert> = {};
    if (parsed.data.referralCommissionPercent !== undefined) {
      updates.referralCommissionPercent = String(parsed.data.referralCommissionPercent);
    }
    if (parsed.data.minWithdrawal !== undefined) {
      updates.minWithdrawal = String(parsed.data.minWithdrawal);
    }
    if (parsed.data.appName !== undefined) updates.appName = parsed.data.appName;
    if (parsed.data.primaryColor !== undefined) updates.primaryColor = parsed.data.primaryColor;
    if (parsed.data.logoText !== undefined) updates.logoText = parsed.data.logoText;
    if ("appDownloadUrl" in parsed.data) updates.appDownloadUrl = parsed.data.appDownloadUrl ?? null;
    if ("telegramUrl" in parsed.data) updates.telegramUrl = parsed.data.telegramUrl ?? null;
    if ("whatsappUrl" in parsed.data) updates.whatsappUrl = parsed.data.whatsappUrl ?? null;
    if (parsed.data.referralFirstTaskBonus !== undefined) {
      updates.referralFirstTaskBonus = String(parsed.data.referralFirstTaskBonus);
    }
    if (parsed.data.level2CommissionPercent !== undefined) {
      updates.level2CommissionPercent = String(parsed.data.level2CommissionPercent);
    }

    if (!rows[0]) {
      const [created] = await db.insert(appSettingsTable).values({
        referralCommissionPercent: updates.referralCommissionPercent ?? "5",
        minWithdrawal: updates.minWithdrawal ?? "50",
        appName: updates.appName ?? "Earn Space",
        primaryColor: updates.primaryColor ?? "#e11d48",
        logoText: updates.logoText ?? "E",
      }).returning();
      return res.json(formatSettings(created!));
    }

    const [updated] = await db.update(appSettingsTable).set(updates).returning();
    return res.json(formatSettings(updated!));
  } catch (err) {
    logger.error({ err }, "Update settings error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
