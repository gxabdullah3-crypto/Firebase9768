import express, { type Express } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import pinoHttp from "pino-http";
import { logger } from "./lib/logger";
import { pool } from "@workspace/db";
import router from "./routes";

const app: Express = express();

// Trust Replit's reverse proxy so secure cookies work over HTTPS
app.set("trust proxy", 1);

const PgSession = connectPgSimple(session);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return { id: req.id, method: req.method, url: req.url?.split("?")[0] };
      },
      res(res) {
        return { statusCode: res.statusCode };
      },
    },
  }),
);

app.use(cors({ credentials: true, origin: true }));
app.use(cookieParser());
app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ extended: true, limit: "20mb" }));

app.use(
  session({
    store: new PgSession({
      pool,
      tableName: "session",
      createTableIfMissing: true,
    }),
    secret: process.env.SESSION_SECRET || "earn-space-secret-key-change-in-prod",
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 30 * 24 * 60 * 60 * 1000,
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
    },
  }),
);

app.use("/api", router);

// Keep the Neon database endpoint alive — it suspends after ~5 min of inactivity.
// Ping every 4 minutes so publish never hits a suspended endpoint.
setInterval(async () => {
  try {
    await pool.query("SELECT 1");
  } catch {
    // silent — if the ping fails we just let the next real request reconnect
  }
}, 4 * 60 * 1000);

export default app;
