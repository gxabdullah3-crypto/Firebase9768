import { and, eq, gte, sql } from "drizzle-orm";
import type { ExtractTablesWithRelations } from "drizzle-orm";
import type { NodePgTransaction } from "drizzle-orm/node-postgres";
import * as schema from "@workspace/db/schema";
import { balanceTransactionsTable, usersTable } from "@workspace/db";
import { centsToDecimal, decimalToCents } from "./money";

type WalletTransaction = NodePgTransaction<
  typeof schema,
  ExtractTablesWithRelations<typeof schema>
>;
type Wallet = "main" | "investment";

interface WalletEntryInput {
  userId: number;
  wallet: Wallet;
  transactionType: string;
  amount: string;
  description: string;
  idempotencyKey: string;
  referenceId?: number | null;
  actorId?: number | null;
}

export class WalletMutationError extends Error {
  constructor(message: string, readonly code: "USER_NOT_FOUND" | "INSUFFICIENT_BALANCE") {
    super(message);
    this.name = "WalletMutationError";
  }
}

export async function applyWalletEntry(tx: WalletTransaction, entry: WalletEntryInput) {
  const amountCents = decimalToCents(entry.amount);
  if (amountCents === 0n) throw new Error("Wallet entries must be non-zero");
  const amount = centsToDecimal(amountCents);
  const isMain = entry.wallet === "main";
  const currentColumn = isMain ? usersTable.balance : usersTable.investmentBalance;
  const magnitude = centsToDecimal(amountCents < 0n ? -amountCents : amountCents);

  const updated = isMain
    ? await tx.update(usersTable)
        .set({
          balance: amountCents > 0n
            ? sql`${usersTable.balance} + ${magnitude}::numeric`
            : sql`${usersTable.balance} - ${magnitude}::numeric`,
        })
        .where(amountCents < 0n
          ? and(eq(usersTable.id, entry.userId), gte(currentColumn, magnitude))
          : eq(usersTable.id, entry.userId))
        .returning({ balance: usersTable.balance })
    : await tx.update(usersTable)
        .set({
          investmentBalance: amountCents > 0n
            ? sql`${usersTable.investmentBalance} + ${magnitude}::numeric`
            : sql`${usersTable.investmentBalance} - ${magnitude}::numeric`,
        })
        .where(amountCents < 0n
          ? and(eq(usersTable.id, entry.userId), gte(currentColumn, magnitude))
          : eq(usersTable.id, entry.userId))
        .returning({ balance: usersTable.investmentBalance });

  const updatedBalance = updated[0]?.balance;
  if (updatedBalance === undefined) {
    const [user] = await tx.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.id, entry.userId));
    throw new WalletMutationError(
      user ? "Insufficient wallet balance" : "User not found",
      user ? "INSUFFICIENT_BALANCE" : "USER_NOT_FOUND",
    );
  }

  const [transaction] = await tx.insert(balanceTransactionsTable).values({
    userId: entry.userId,
    wallet: entry.wallet,
    transactionType: entry.transactionType,
    amount,
    balanceAfter: updatedBalance,
    description: entry.description,
    idempotencyKey: entry.idempotencyKey,
    referenceId: entry.referenceId ?? null,
    actorId: entry.actorId ?? null,
  }).returning();

  if (!transaction) throw new Error("Failed to record wallet transaction");
  return { transaction, balanceAfter: updatedBalance };
}