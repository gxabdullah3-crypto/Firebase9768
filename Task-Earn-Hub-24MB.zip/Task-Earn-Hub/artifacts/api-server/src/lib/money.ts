export function decimalToCents(value: string | number): bigint {
  const normalized = String(value);
  const match = /^(-?)(\d+)(?:\.(\d{1,2}))?$/.exec(normalized);
  if (!match) throw new Error(`Invalid money value: ${normalized}`);
  const sign = match[1] === "-" ? -1n : 1n;
  const whole = BigInt(match[2]!);
  const fraction = BigInt((match[3] ?? "").padEnd(2, "0"));
  return sign * (whole * 100n + fraction);
}

export function centsToDecimal(cents: bigint): string {
  const sign = cents < 0n ? "-" : "";
  const absolute = cents < 0n ? -cents : cents;
  return `${sign}${absolute / 100n}.${String(absolute % 100n).padStart(2, "0")}`;
}

export function calculateSimpleProfitCents(
  principalCents: bigint,
  ratePercent: string | number,
  termDays: number,
  ratePeriodDays: number,
): bigint {
  const rateHundredths = decimalToCents(ratePercent);
  const numerator = principalCents * rateHundredths * BigInt(termDays);
  const denominator = 10_000n * BigInt(ratePeriodDays);
  return (numerator + denominator / 2n) / denominator;
}