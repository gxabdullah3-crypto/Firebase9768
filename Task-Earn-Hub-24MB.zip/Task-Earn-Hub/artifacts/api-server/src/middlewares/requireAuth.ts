import { Request, Response, NextFunction } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

type CurrentUser = typeof usersTable.$inferSelect;

declare global {
  namespace Express {
    interface Request {
      currentUser?: CurrentUser;
    }
  }
}

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const userId = req.session?.userId;
  if (!userId) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    if (!user) return res.status(401).json({ error: "Unauthorized" });
    req.currentUser = user;
    return next();
  } catch {
    return res.status(500).json({ error: "Internal server error" });
  }
}

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.currentUser || req.currentUser.role !== "admin") {
    return res.status(403).json({ error: "Admin access required" });
  }
  return next();
}

export function requireAdminOrAssistant(req: Request, res: Response, next: NextFunction) {
  if (!req.currentUser || !["admin", "assistant"].includes(req.currentUser.role)) {
    return res.status(403).json({ error: "Admin or assistant access required" });
  }
  return next();
}
