---
name: Orval void mutation variable type
description: How to call Orval-generated mutations that take void as variable type
---

When Orval generates a mutation endpoint with no request body (e.g. POST /auth/logout), the generated type is `UseMutationResult<..., void, ...>` where the third generic (TVariables) is `void`.

**Rule:** Call `mutate(undefined, { onSuccess, onError })` — NOT `mutate({}, { ... })`.

**Why:** TypeScript treats `void` strictly — `{}` is not assignable to `void`. The correct call is `mutate(undefined)` or `mutate()`.

**How to apply:** Check generated `.ts` files for the `TVariables` generic. If it's `void`, always pass `undefined` (or nothing) as the first argument to `.mutate()`.
