---
name: Express Request type augmentation
description: How to augment Express Request in this project's tsconfig setup
---

When `tsconfig.json` has `"types": ["node"]` (no express in types array), `declare module "express-serve-static-core"` fails with TS2664.

**Rule:** Use the global namespace approach instead:

```typescript
type CurrentUser = typeof usersTable.$inferSelect;

declare global {
  namespace Express {
    interface Request {
      currentUser?: CurrentUser;
    }
  }
}
```

**Why:** The `"types": ["node"]` restriction prevents the compiler from resolving `express-serve-static-core` as an augmentation target, but the global `Express` namespace is always available when `@types/express` is installed.

**How to apply:** Any time you need to add properties to `req` in an Express route, use the global namespace in `requireAuth.ts` or a dedicated types file.
